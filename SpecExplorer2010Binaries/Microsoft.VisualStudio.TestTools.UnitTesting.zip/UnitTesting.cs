﻿// Microsoft.VisualStudio.TestTools.UnitTesting stubbing
namespace Microsoft.VisualStudio.TestTools.UnitTesting
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Reflection;

    [System.AttributeUsage(System.AttributeTargets.Method)]
    public class TestMethodAttribute : System.Attribute
    {
        public TestMethodAttribute()
        {
        }
    }
   
    [System.AttributeUsage(System.AttributeTargets.Method)]
    public class TestPropertyAttribute : System.Attribute
    {
        public TestPropertyAttribute(string Name, string ID)
        {
        }
    }

    // Requirement tags.
    [System.AttributeUsage(System.AttributeTargets.Method)]
    public class DescriptionAttribute : System.Attribute
    {
        public DescriptionAttribute (string Name)
        {
        }
    }
    
    // Initialisation decorator.
    [System.AttributeUsage(System.AttributeTargets.Method)]
    public class TestInitializeAttribute : System.Attribute
    {
        public TestInitializeAttribute()
        {
        }
    }

    // Decorator for test script end.
    [System.AttributeUsage(System.AttributeTargets.Method)]
    public class TestCleanupAttribute : System.Attribute
    {
        public TestCleanupAttribute()
        {
        }
    }

    // Decorator of test class.
    [System.AttributeUsage(System.AttributeTargets.Class |
                           System.AttributeTargets.Struct)
    ]
    public class TestClassAttribute: System.Attribute
    {
        public TestClassAttribute()
        {
        }
    }

}


