using System;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Microsoft.SpecExplorer.Runtime.Testing
{
    /// <summary>
    /// A type to describe an expected event.
    /// </summary>
    public struct ExpectedEvent
    {
        /// <summary>
        /// The event waited for, identified by its
        /// reflection representation.
        /// </summary>
        public EventInfo Event
        {
            get;
            private set;
        }
                
        /// <summary>
        /// The target of the event (the instance object where the event
        /// belongs too), or null, if it is a static or an adapter event.
        /// </summary>
        public object Target
        {
            get;
            private set;
        }

        /// <summary>
        /// The checker to be called when the event
        /// arrives. 
        /// </summary>
        public Delegate Checker
        {
            get;
            private set;
        }
        
        /// <summary>
        /// The way how to call the checker.
        /// </summary>
        internal readonly CheckerCallingStyle callingStyle;

        /// <summary>
        /// Constructs an expected event.
        /// </summary>
        /// <param name="eventInfo">The reflection information of the event.</param>
        /// <param name="target">The target object. Must be null for static events and for adapter events.</param>
        /// <param name="checker">
        ///     The checker. Must match the type of the event. A compatible type is a delegate type
        ///     either taking an array of objects as arguments, exactly the arguments of the event, or
        ///     exactly the arguments of the event preceded by an instance of the event target.      
        /// </param>
        /// <returns></returns>
        public ExpectedEvent(EventInfo eventInfo, object target, Delegate checker):this()
        {
            this.Event = eventInfo;
            this.Target = target;
            this.Checker = checker;
   
            bool requiresTarget = TestManagerHelpers.RequiresTarget(eventInfo);
            if (requiresTarget && target == null)
                throw new InvalidOperationException(String.Format(
                    "instance based event '{0}' which does not originate from adapter requires target object", eventInfo));
            else if (!requiresTarget && target != null)
                throw new InvalidOperationException(String.Format(
                    "static or adapter event '{0}' must not be combined with target object", eventInfo));

            if (checker != null)
            {
                this.callingStyle = TestManagerHelpers.GetEventCheckerCallingStyle(eventInfo, checker.GetType());
            }
            else
            {
                this.callingStyle = CheckerCallingStyle.ParametersDirect;
            }
            if (this.callingStyle == CheckerCallingStyle.Invalid)
                throw new InvalidOperationException(String.Format(
                    "checker for event '{0}' has incompatible type", eventInfo));

        }

        /// <summary>
        /// Delivers readable representation.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            if (Target != null)
            {
                result.Append(TestManagerHelpers.Describe(Target));
                result.Append(".");
            }
            result.Append("event ");
            result.Append(Event.Name);
            result.Append("(...)");
            return result.ToString();
        }

       
    }

    /// <summary>
    /// A type to describe an expected method return.
    /// </summary>
    public struct ExpectedReturn
    {
        /// <summary>
        /// The method for which a return is expected,
        /// identified by its reflection representation
        /// </summary>
        public MethodBase Method
        {
            get;
            private set;
        }

        /// <summary>
        /// The target of the method (the instance object where the method
        /// belongs too), or null, if it is a static or an adapter method.
        /// </summary>
        public object Target
        {
            get;
            private set;
        }

        /// <summary>
        /// The checker to be called when the method return
        /// arrives. 
        /// </summary>
        public Delegate Checker
        {
            get;
            private set;
        }

        /// <summary>
        /// The way how to call the checker.
        /// </summary>
        internal readonly CheckerCallingStyle callingStyle;

        /// <summary>
        /// Constructs an expected method return.
        /// </summary>
        /// <param name="methodInfo">The reflection information of the method.</param>
        /// <param name="target">The target object. Must be null for static methods and for adapter methods.</param>
        /// <param name="checker">
        ///     The checker. Must match the type of the method. A compatible type is a delegate type
        ///     either taking an array of objects as arguments, exactly the arguments of the method outputs, or
        ///     exactly the arguments of the method outputs preceded by an instance of the method target.     
        /// </param>
        /// <returns></returns>
        public ExpectedReturn(MethodBase methodInfo, object target, Delegate checker):this()
        {
            this.Method = methodInfo;
            this.Target = target;
            this.Checker = checker;

            bool requiresTarget = TestManagerHelpers.RequiresTarget(methodInfo);
            if (requiresTarget && target == null)
                throw new InvalidOperationException(String.Format(
                    "instance based return of method '{0}' which does not originate from adapter requires target object", methodInfo));
            else if (!requiresTarget && target != null)
                throw new InvalidOperationException(String.Format(
                    "static or adapter return of method '{0}' must not be combined with target object", methodInfo));

            if (checker != null)
            {
                this.callingStyle = TestManagerHelpers.GetReturnCheckerCallingStyle(methodInfo, checker.GetType());
            }
            else
            {
                this.callingStyle = CheckerCallingStyle.Invalid;
            }

            if (this.callingStyle == CheckerCallingStyle.Invalid)
                throw new InvalidOperationException(String.Format(
                    "checker for return of method '{0}' has incompatible type", methodInfo));
        }
  
        /// <summary>
        /// Delivers readable representation.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            if (Target != null)
            {
                result.Append(TestManagerHelpers.Describe(Target));
                result.Append(".");
            }
            result.Append("event ");
            result.Append(Method.Name);
            result.Append("(...)");
            return result.ToString();
        }

    }


    /// <summary>
    /// A type to describe an expected pre constraint
    /// </summary>
    public struct ExpectedPreConstraint
    {
        /// <summary>
        /// The checker to be called when test manager intend to check preconstraint attached to transition.
        /// </summary>
        /// <remarks>
        /// The checker has no parameter or return value.
        /// </remarks>
        public Delegate Checker
        {
            get;
            private set;
        }

        /// <summary>
        /// The constructor.
        /// </summary>
        /// <param name="checker"></param>
        public ExpectedPreConstraint(Delegate checker) : this()
        {
            this.Checker = checker;
        }
    }

    /// <summary>
    /// An enumeration indicating how to invoke a checker.
    /// </summary>
    internal enum CheckerCallingStyle
    {
        Invalid,
        ParametersDirect,
        TargetAndParametersDirect,
        ParametersArray,
        TargetAndParametersArray
    }


    /// <summary>
    /// A type to describe an available event.
    /// </summary>
    public struct AvailableEvent
    {
        /// <summary>
        /// The event identified by its
        /// reflection representation.
        /// </summary>
        public EventInfo Event
        {
            get;
            private set;
        }
 
        /// <summary>
        /// The target of the event (the instance object where the event
        /// belongs too), or null, if it is a static or an adapter event.
        /// </summary>
        public object Target
        {
            get;
            private set;
        }

        /// <summary>
        /// The parameters passed to the event.
        /// </summary>
        public object[] Parameters
        {
            get;
            private set;
        }

        /// <summary>
        /// Constructs a new <see cref="AvailableEvent"/>.
        /// </summary>
        /// <param name="eventInfo"></param>
        /// <param name="target"></param>
        /// <param name="parameters"></param>
        public AvailableEvent(EventInfo eventInfo, object target, object[] parameters):this()
        {
            this.Event = eventInfo;
            this.Target = target;
            this.Parameters = parameters;
        }

        /// <summary>
        /// Delivers readable representation.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            if (Target != null)
            {
                result.Append(TestManagerHelpers.Describe(Target));
                result.Append(".");
            }
            result.Append("event ");
            result.Append(Event.Name);
            result.Append("(");
            bool first = true;
            foreach (object param in Parameters)
            {
                if (first)
                    first = false;
                else
                    result.Append(",");
                result.Append(TestManagerHelpers.Describe(param));
            }
            result.Append(")");
            return result.ToString();
        }

    }

    /// <summary>
    /// A type to describe an available return.
    /// </summary>
    public struct AvailableReturn
    {
        /// <summary>
        /// The method identifier by
        /// its reflection representation,
        /// </summary>
        public MethodBase Method
        {
            get;
            private set;
        }

        /// <summary>
        /// The target of the method (the instance object where the method
        /// belongs too), or null, if it is a static or an adapter method.
        /// </summary>
        public object Target
        {
            get;
            private set;
        }

        /// <summary>
        /// The parameters passed to the return.
        /// </summary>
        public object[] Parameters
        {
            get;
            private set;
        }

        internal AvailableReturn(MethodBase methodInfo, object target, object[] parameters):this()
        {
            this.Method = methodInfo;
            this.Target = target;
            this.Parameters = parameters;
        }

        /// <summary>
        /// Delivers readable representation.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            if (Target != null)
            {
                result.Append(TestManagerHelpers.Describe(Target));
                result.Append(".");
            }
            result.Append("return ");
            result.Append(Method.Name);
            result.Append("(");
            bool first = true;
            Type returnType;
            if (Method is MethodInfo)
                returnType = ((MethodInfo)Method).ReturnType;
            else
                returnType = null;
            bool hasReturn = returnType != null && returnType != typeof(void);
            int i = hasReturn ? 1 : 0;
            foreach (ParameterInfo pinfo in Method.GetParameters())
            {
                if (pinfo.ParameterType.IsByRef)
                {
                    if (first)
                        first = false;
                    else
                        result.Append(",");
                    if ((pinfo.Attributes & ParameterAttributes.Out) != ParameterAttributes.None)
                        result.Append("out ");
                    else
                        result.Append("ref ");
                    result.Append(Parameters[i++]);
                }
            }
            result.Append(")");
            if (hasReturn)
            {
                result.Append("/");
                result.Append(TestManagerHelpers.Describe(Parameters[0]));
            }
            return result.ToString();
        }
    }
  
    /// <summary>
    /// The base type of test managers.
    /// </summary>
    public interface ITestManager
    {

        #region Adapters

        /// <summary>
        /// Retrieves singleton instance of an adapter of the given type; throws exception on failure.
        /// </summary>
        /// <param name="adapterType"></param>
        /// <returns></returns>
        object GetAdapter(Type adapterType);

        #endregion

        #region PreConstraint

        /// <summary>
        /// select one satisfied pre-constraint from one or more expected preconstraints described by patterns.
        /// </summary>   
        /// <param name="failIfNone">Behavior on failure.</param>
        /// <param name="expected">Expected pre constraints</param>
        /// <returns>
        ///  Returns index of expected if preconstraint is satisfied.
        ///  if none of the pre-constraints satisfies, returns -1 if <c>failIfNone</c> is false, otherwise
        ///  produces test failure with corresponding diagnostics.
        /// </returns>
        int SelectSatisfiedPreConstraint(bool failIfNone, params ExpectedPreConstraint[] expected);

        #endregion

        #region Event Queue

        /// <summary>
        /// Let test manager subscribe to the given event. Events raised
        /// on this <paramref name="eventInfo"/> will be propagated to the event queue.
        /// </summary>
        /// <param name="eventInfo">The event reflection information.</param>
        /// <param name="target">The target (instance to which the event belongs).</param>
        void Subscribe(EventInfo eventInfo, object target);

        /// <summary>
        /// Let test manager unsubscribe from the given event.
        /// </summary>
        /// <param name="eventInfo">The event reflection information.</param>
        /// <param name="target">The target (instance to which the event belongs).</param>
        void Unsubscribe(EventInfo eventInfo, object target);

        /// <summary>
        /// Adds an event to the event queue.
        /// </summary>
        /// <param name="eventInfo">The reflection information of the event.</param>
        /// <param name="target">
        /// The target object. Must be given for instance-based, non-adapter methods, 
        /// otherwise must be null.
        ///  </param>
        /// <param name="arguments">the arguments to the return method.</param>
        void AddEvent(EventInfo eventInfo, object target, params object[] arguments);
  
        /// <summary>
        /// Expect one or more events described by patterns.
        /// </summary>
        /// <param name="timeOut">Time to wait for event.</param>
        /// <param name="failIfNone">Behavior on failure.</param>
        /// <param name="expected">Expected events</param>
        /// <returns>
        ///  Returns index of expected which matched if event is available in time.
        ///  If event is not available, returns -1 if <c>failIfNone</c> is false, otherwise
        ///  produces test failure with regarding diagnostics.
        /// </returns>
        int ExpectEvent(TimeSpan timeOut, bool failIfNone, params ExpectedEvent[] expected);

        /// <summary>
        /// Try get next available event in event queue.
        /// </summary>
        /// <param name="timeOut">Time to wait for event.</param>
        /// <param name="consume">If true, event will be removed from queue of available</param>
        /// <param name="availableEvent">Holds the available event.</param>
        /// <returns>True if event is available within time limits.</returns>
        bool TryGetNextEvent(TimeSpan timeOut, bool consume, out AvailableEvent availableEvent);


        #endregion

        #region Return Queue

        /// <summary>
        /// Adds a method return to the return queue.
        /// </summary>
        /// <param name="methodInfo">The reflection information of the method.</param>
        /// <param name="target">The target object. Must be given for instance-based, non-adapter methods, 
        ///   must be null otherwise.</param>
        /// <param name="arguments"></param>
        void AddReturn(MethodBase methodInfo, object target, params object[] arguments);

        /// <summary>
        /// Expect one or more returns described by patterns.
        /// </summary>
        /// <param name="timeOut">Time to wait for return.</param>
        /// <param name="failIfNone">Behavior on failure.</param>
        /// <param name="expected">Expected returns</param>
        /// <returns>
        ///  Returns index of expected which matched if return is available in time.
        ///  If return is not available, returns -1 if <c>failIfNone</c> is false, otherwise
        ///  produces test failure with regarding diagnostics.
        /// </returns>
        int ExpectReturn(TimeSpan timeOut, bool failIfNone, params ExpectedReturn[] expected);

        /// <summary>
        /// Try get next available return in return queue.
        /// </summary>
        /// <param name="timeOut">Time to wait for event.</param>
        /// <param name="consume">If true, event will be removed from queue of available</param>
        /// <param name="availableReturn">Holds the available event.</param>
        /// <returns>True if return is available within time limits.</returns>
        bool TryGetNextReturn(TimeSpan timeOut, bool consume, out AvailableReturn availableReturn);
        

        #endregion

        #region Test Execution

        /// <summary>
        /// Begins executing a test case.
        /// </summary>
        /// <param name="name"></param>
        void BeginTest(string name);

        /// <summary>
        /// Ends executing a test case.
        /// </summary>
        void EndTest();

        /// <summary>
        /// Executes a test assertion.
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="description"></param>
        void Assert(bool condition, string description);

        /// <summary>
        /// Executes a test assumption.
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="description"></param>
        void Assume(bool condition, string description);
        
        /// <summary>
        /// Executes a checkpoint.
        /// </summary>
        /// <param name="description"></param>
        void Checkpoint(string description);

        /// <summary>
        /// Logs a comment about test execution.
        /// </summary>
        /// <param name="description"></param>
        void Comment(string description);

        /// <summary>
        /// Upon observation timeout, checks current event observation queue status and decides 
        /// whether case should pass or fail.
        /// </summary>
        /// <param name="isAcceptingState"></param>
        /// <param name="expected"></param>
        void CheckObservationTimeout(bool isAcceptingState, params ExpectedEvent[] expected);

        #endregion

        #region Variables and Transactions

        /// <summary>
        /// Creates a new variable which can be transacted.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="name"></param>
        /// <returns></returns>
        IVariable<T> CreateVariable<T>(string name);

        /// <summary>
        /// Generates a default value of type T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        T GenerateValue<T>();

        /// <summary>
        /// Random seed for value generation.
        /// </summary>
        int RandomSeed { get; set; }

        /// <summary>
        /// Begins a transaction. Note that the execution of a Checker happens implicitly within a transaction.
        /// </summary>
        void BeginTransaction();

        /// <summary>
        /// Ends transaction, either committing variables which have been bound, or rolling them back. 
        /// Note that the execution of a Checker happens implicitly within a transaction.
        /// </summary>
        /// <param name="commit"></param>
        void EndTransaction(bool commit);

        #endregion

        /// <summary>
        /// if true, throw predefined <see cref="TestFailureException"/> when assertion fails and dynamic traversal
        /// can catch it and decide how to proceed.
        /// Otherwise, leaves to test control manager to handle assertion failure.
        /// </summary>
        bool ThrowTestFailureException { get; set; }
                
    }

    /// <summary>
    /// Type representing a transacted variable.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IVariable<T>
    {
        /// <summary>
        /// Determines whether the variable is bound.
        /// </summary>
        bool IsBound { get; }

        /// <summary>
        /// Resets the variable to unbound state, so that it
        /// can be bound to new value later.
        /// </summary>
        void Unbind();

        /// <summary>
        /// Gets or sets a value. If the variable is bound, setting
        /// will result in an equality check on its current value
        /// with the given value. If the variable is unbound, getting
        /// will result in generation of a default value.
        /// </summary>
        T Value { get; set; }
    }
}
