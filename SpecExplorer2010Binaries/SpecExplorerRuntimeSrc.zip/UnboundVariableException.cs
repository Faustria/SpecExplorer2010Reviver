using System;

namespace Microsoft.SpecExplorer.Runtime.Testing
{
    /// <summary>
    /// An exception which is thrown when variable is read before it is bound.
    /// </summary>
    [Serializable]
    public class UnboundVariableException : Exception
    {
        /// <summary>
        /// Constructs the UnboundVariableException.
        /// </summary>
        public UnboundVariableException()
            : base()
        { }

        /// <summary>
        /// Constructs the UnboundVariableException.
        /// </summary>
        /// <param name="message">error message</param>
        public UnboundVariableException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Constructs the UnboundVariableException.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="innerException">The inner exception.</param>
        public UnboundVariableException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

#if !COMPACT
        /// <summary>
        /// Constructs the UnboundVariableException.
        /// </summary>
        /// <param name="serializationInfo"></param>
        /// <param name="streamingContext"></param>
        protected UnboundVariableException(System.Runtime.Serialization.SerializationInfo serializationInfo, System.Runtime.Serialization.StreamingContext streamingContext)
            : base(serializationInfo, streamingContext)
        {
        }

#endif
    }
}
