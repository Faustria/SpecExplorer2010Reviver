using System;
using System.Runtime.Serialization;

namespace Microsoft.SpecExplorer.Runtime.Testing
{
    /// <summary>
    /// Class representing the exceptional case of a failed transaction.
    /// </summary>
    [Serializable]
    public class TransactionFailedException : Exception
    {
        /// <summary>
        /// Constructs transaction failed exception
        /// </summary>
        public TransactionFailedException()
            : base()
        {
        }

        /// <summary>
        /// Constructs transaction failed exception
        /// </summary>
        /// <param name="message">The message text.</param>
        public TransactionFailedException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Constructs transaction failed exception
        /// </summary>
        /// <param name="message">The message text.</param>
        /// <param name="innerException">The inner exception.</param>
        public TransactionFailedException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

#if !COMPACT

        /// <summary>
        /// Constructs transaction failed exception
        /// </summary>
        protected TransactionFailedException(SerializationInfo serializationInfo, StreamingContext streamingContext)
            : base(serializationInfo, streamingContext)
        {
        }

#endif
    }
}
