using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Microsoft.SpecExplorer.Runtime.Testing
{
    /// <summary>
    /// The default test manager, test manager supervises test case running process, and provides
    /// logging and checking functionality.
    /// </summary>
    public class DefaultTestManager : ITestManager
    {

        #region Helper Types

        enum TransactionEventKind
        {
            Assert,
            Assume,
            Checkpoint,
            Comment,
            VariableBound
        }

        struct TransactionEvent
        {
            internal TransactionEventKind Kind;
            internal bool condition;
            internal string description;
            internal VariableBase variable;
       
            internal TransactionEvent(TransactionEventKind kind, bool condition, string description, VariableBase variable)
            {
                this.Kind = kind;
                this.condition = condition;
                this.description = description;
                this.variable = variable;
            }
        }

        abstract class VariableBase
        {
            internal abstract void InternalUnbind();
            internal abstract string Name { get; }
            internal abstract object ObjectValue { get; }
        }

        class Variable<T> : VariableBase, IVariable<T>
        {
            string name;
            T value;
            bool isBound;
            DefaultTestManager manager;

            internal Variable(string name, DefaultTestManager manager)
            {
                this.name = name;
                this.manager = manager;
            }

            public void Unbind()
            {
                InternalUnbind();
            }

            internal override void InternalUnbind()
            {
                isBound = false;
                value = default(T);
            }

            internal override string Name
            {
                get { return name; }
            } 

            internal override object  ObjectValue
            {
                get { return value; }
            }

            #region IVariable<T>

            /// <summary>
            /// Determines whether the variable is bound.
            /// </summary>
            public bool IsBound
            {
                get { return isBound; }
            }


            /// <summary>
            /// Gets or sets a value. If the variable is bound, setting
            /// will result in an equality check on its current value
            /// with the given value. If the variable is unbound, getting
            /// will result in generation of a default value.
            /// </summary>
            public T Value
            {
                get
                {
                    if (!isBound)
                    {
                        throw new UnboundVariableException("Variable's value cannot be read before it is bound");
                    }
                    return value;
                }
                set
                {
                    if (!isBound)
                    {
                        this.value = value;
                        isBound = true;
                    }
                    else
                    {
                        manager.Assert(Object.Equals(this.value, value),
                                       String.Format(
                                "bound variable '{0}' can only be assigned to equal value (bound value: '{1}', new value: '{2}')", 
                                this.name, this.value, value));
                    }
                }
            }

            #endregion
        }

        #endregion

        #region State and Construction

        IBasicTestSite site;

        List<TransactionEvent> transaction;

        bool inTransaction { get { return transaction != null; } }

        int randomSeed;

        ObservationQueue<AvailableEvent> eventQueue;
        ObservationQueue<AvailableReturn> returnQueue;

        static Dictionary<EventInfo, Delegate> staticEventHandlers = new Dictionary<EventInfo, Delegate>();
        static Dictionary<EventInfo, Dictionary<object, Delegate>> instanceEventHandlers = new Dictionary<EventInfo, Dictionary<object, Delegate>>();

        // work around: we have to cache adapter instances in per type basis, because adapter potentially can be 
        // implemented with transparent proxy, and its HashCode/Equality is not properly defined (known problem of PTF)
        static Dictionary<EventInfo, Dictionary<Type, Delegate>> adapterEventHandlers = new Dictionary<EventInfo, Dictionary<Type, Delegate>>();
                
        /// <summary>
        /// Constructs a test manager base, with given test site, maximal sizes for event and return queue.
        /// </summary>
        /// <param name="site">Basic test site.</param>
        /// <param name="maxEventQueueSize">Maximal size for event queue. Not implemented yet.</param>
        /// <param name="maxReturnQueueSize">Maximal size for return queue. Not implemented yet.</param>
        public DefaultTestManager(IBasicTestSite site, int maxEventQueueSize, int maxReturnQueueSize)
        {
            this.site = site;
            eventQueue = new ObservationQueue<AvailableEvent>(maxEventQueueSize);
            returnQueue = new ObservationQueue<AvailableReturn>(maxReturnQueueSize);
        }

        /// <summary>
        /// Constructs a test manager base.
        /// </summary>
        protected DefaultTestManager(IBasicTestSite site)
            : this(site, 32, 8)
        {
        }

        #endregion

        #region Adapters

        /// <summary>
        /// Retrieves singleton instance of an adapter of the given type; throws exception on failure.
        /// </summary>
        /// <param name="adapterType"></param>
        /// <returns></returns>
        public virtual object GetAdapter(Type adapterType)
        {
            return site.GetAdapter(adapterType);
        }

        #endregion

        #region Event Queues

        /// <summary>
        /// Let test manager subscribe to the given event. Events raised
        /// on this <paramref name="eventInfo"/> will be propagated to the event queue.
        /// </summary>
        /// <param name="eventInfo">The event reflection information.</param>
        /// <param name="target">The target (instance to which the event belongs).</param>
        public virtual void Subscribe(EventInfo eventInfo, object target)
        {
            Delegate handler;
            bool created = false;
            if (target == null)
            {
                // static event
                if (!staticEventHandlers.TryGetValue(eventInfo, out handler))
                {
                    handler = TestManagerHelpers.Generate(eventInfo, null, AddEvent);
                    staticEventHandlers[eventInfo] = handler;
                    created = true;
                }
            }
            else if (TestManagerHelpers.IsAdapter(target.GetType()))
            {
                Dictionary<Type, Delegate> handlers;
                Type type = target.GetType();
                if (!adapterEventHandlers.TryGetValue(eventInfo, out handlers))
                {
                    handlers = new Dictionary<Type, Delegate>();
                    adapterEventHandlers[eventInfo] = handlers;
                }
                if (!handlers.TryGetValue(type, out handler))
                {
                    handler = TestManagerHelpers.Generate(eventInfo, target, AddEvent);
                    handlers[type] = handler;
                    created = true;
                }
            }
            else
            {
                Dictionary<object, Delegate> handlers;
                if (!instanceEventHandlers.TryGetValue(eventInfo, out handlers))
                {
                    handlers = new Dictionary<object, Delegate>();
                    instanceEventHandlers[eventInfo] = handlers;
                }
                if (!handlers.TryGetValue(target, out handler))
                {
                    handler = TestManagerHelpers.Generate(eventInfo, target, AddEvent);
                    handlers[target] = handler;
                    created = true;
                }
            }
            if (!created)
            {
                // re-using an old handler need to ensure the processor is based on
                // this instance of test manager
                TestManagerHelpers.UpdateEventHandlerProcessor(handler, AddEvent);
            }
            eventInfo.RemoveEventHandler(target, handler); // be sure we do not double-add event handler
            eventInfo.AddEventHandler(target, handler);
        }

        /// <summary>
        /// Let test manager unsubscribe from the given event.
        /// </summary>
        /// <param name="eventInfo">The event reflection information.</param>
        /// <param name="target">The target (instance to which the event belongs).</param>
        public virtual void Unsubscribe(EventInfo eventInfo, object target)
        {
            Delegate handler;
            if (target == null)
            {
                // static event
                if (!staticEventHandlers.TryGetValue(eventInfo, out handler))
                {
                    return;
                }
            }
            else if (TestManagerHelpers.IsAdapter(target.GetType()))
            {
                Dictionary<Type, Delegate> handlers;
                Type type = target.GetType();
                if (!adapterEventHandlers.TryGetValue(eventInfo, out handlers))
                {
                    return;
                }
                if (!handlers.TryGetValue(type, out handler))
                {
                    return;
                }
            }
            else
            {
                Dictionary<object, Delegate> handlers;
                if (!instanceEventHandlers.TryGetValue(eventInfo, out handlers))
                {
                    return;
                }
                if (!handlers.TryGetValue(target, out handler))
                {
                    return;
                }
                handlers.Remove(target); // don't cache for instance events to avoid leaks on impl. objects
            }
            eventInfo.RemoveEventHandler(target, handler);
        }

        /// <summary>
        /// Adds an event to the event queue.
        /// </summary>
        /// <param name="eventInfo">The reflection information of the event.</param>
        /// <param name="target">
        /// The target object. Must be given for instance-based, non-adapter methods, 
        /// otherwise must be null.
        ///  </param>
        /// <param name="arguments">the arguments to the return method.</param>
        public virtual void AddEvent(EventInfo eventInfo, object target, object[] arguments)
        {
            if (!TestManagerHelpers.RequiresTarget(eventInfo))
                target = null;
            eventQueue.Add(new AvailableEvent(eventInfo, target, arguments));
        }

        /// <summary>
        /// Adds a method return to the return queue.
        /// </summary>
        /// <param name="methodInfo">The reflection information of the method.</param>
        /// <param name="target">
        /// The target object. Must be given for instance-based, non-adapter methods, 
        /// must be null otherwise.
        ///  </param>
        /// <param name="arguments">the arguments to the return method.</param>
        public virtual void AddReturn(MethodBase methodInfo, object target, params object[] arguments)
        {
            if (!TestManagerHelpers.RequiresTarget(methodInfo))
                target = null;
            // HACK: we should do some consistency checks here, since in contrast
            // to events, a user can call this method and provide wrong parameters.
            returnQueue.Add(new AvailableReturn(methodInfo, target, arguments));
        }

        /// <summary>
        /// Try get next available event in event queue.
        /// </summary>
        /// <param name="timeOut">Time to wait for event.</param>
        /// <param name="consume">If true, event will be removed from queue of available</param>
        /// <param name="availableEvent">Holds the available event.</param>
        /// <returns>True if event is available within time limits.</returns>
        public virtual bool TryGetNextEvent(TimeSpan timeOut, bool consume, out AvailableEvent availableEvent)
        {
            return eventQueue.TryGet(timeOut, consume, out availableEvent);
        }

        /// <summary>
        /// Try get next available return in return queue.
        /// </summary>
        /// <param name="timeOut">Time to wait for event.</param>
        /// <param name="consume">If true, event will be removed from queue of available</param>
        /// <param name="availableReturn">Holds the available event.</param>
        /// <returns>True if return is available within time limits.</returns>
        public virtual bool TryGetNextReturn(TimeSpan timeOut, bool consume, out AvailableReturn availableReturn)
        {
            return returnQueue.TryGet(timeOut, consume, out availableReturn);
        }   

        void ConsumeEvent()
        {
            AvailableEvent dummy;
            eventQueue.TryGet(TimeSpan.FromSeconds(0), true, out dummy);
        }

        void ConsumeReturn()
        {
            AvailableReturn dummy;
            returnQueue.TryGet(TimeSpan.FromSeconds(0), true, out dummy);
        }

        /// <summary>
        /// Expects one or more events described by patterns.
        /// </summary>
        /// <param name="timeOut">Time to wait for event.</param>
        /// <param name="failIfNone">Behavior on failure.</param>
        /// <param name="expected">Expected events.</param>
        /// <returns>
        ///  Returns index of expected which matched if event is available in time.
        ///  If event is not available, returns -1 if <c>failIfNone</c> is false, otherwise
        ///  produces test failure with corresponding diagnostics.
        /// </returns>
        public virtual int ExpectEvent(TimeSpan timeOut, bool failIfNone, params ExpectedEvent[] expected)
        {
            AvailableEvent availableEvent;
            if (!TryGetNextEvent(timeOut, false, out availableEvent))
            {
                if (failIfNone)
                {
                    StringBuilder diag = new StringBuilder();
                    diag.AppendLine(String.Format("Event must occur within {0}ms", timeOut.TotalMilliseconds));
                    diag.AppendLine("Expecting events:");
                    foreach (var e in expected)
                    {
                        diag.AppendLine("\t" + e.ToString());
                    }
                    InternalAssert(false, diag.ToString());
                }
                return -1;
            }
            List<List<TransactionEvent>> failedTransactions;
            if (failIfNone)
                failedTransactions = new List<List<TransactionEvent>>();
            else
                failedTransactions = null;
            int index = 0;
            foreach (ExpectedEvent expectedEvent in expected)
            {
                if (expectedEvent.Event == availableEvent.Event && expectedEvent.Target == availableEvent.Target)
                {                    
                    BeginTransaction();
                    try
                    {
                        if (expectedEvent.Checker != null)
                        {
                            TestManagerHelpers.CallChecker(expectedEvent.callingStyle, expectedEvent.Checker,
                                                        availableEvent.Target, availableEvent.Parameters);
                        }
                        EndTransaction(true);
                        ConsumeEvent();
                        return index;
                    }
                    catch (TransactionFailedException)
                    {
                        if (failIfNone)
                        {
                            failedTransactions.Add(transaction);
                        }
                        EndTransaction(false);
                    }
                }
                index++;
            }
            if (!failIfNone)
                return -1;

            // build diagnosis
            StringBuilder diagnosis = new StringBuilder();
            index = 0;
            int transactionIndex = 0;
            foreach (ExpectedEvent expectedEvent in expected)
            {
                if (expectedEvent.Event != availableEvent.Event || expectedEvent.Target != availableEvent.Target)
                {
                    diagnosis.AppendLine(String.Format("  {0}. {1} is not matching", 
                            index+1, expectedEvent.ToString()));
                }
                else
                {
                    List<TransactionEvent> t = failedTransactions[transactionIndex++];
                    diagnosis.AppendLine(String.Format("  {0}. event parameters do not match", 
                                        index+1));
                    Describe(diagnosis, "    ", t);
                }
                index++;
            }
            InternalAssert(false, String.Format("expected matching event, found '{0}'. Diagnosis:\r\n{1}",
                            availableEvent.ToString(), diagnosis.ToString()));
            return -1;
        }

        /// <summary>
        /// Expects one or more returns described by patterns.
        /// </summary>
        /// <param name="timeOut">Time to wait for return.</param>
        /// <param name="failIfNone">Behavior on failure.</param>
        /// <param name="expected">Expected returns</param>
        /// <returns>
        ///  Returns index of expected which matched if return is available in time.
        ///  If return is not available, returns -1 if <c>failIfNone</c> is false, otherwise
        ///  produces test failure with corresponding diagnostics.
        /// </returns>
        public virtual int ExpectReturn(TimeSpan timeOut, bool failIfNone, params ExpectedReturn[] expected)
        {
            AvailableReturn availableReturn;
            if (!TryGetNextReturn(timeOut, false, out availableReturn))
            {
                if (failIfNone)
                {
                    InternalAssert(false, String.Format("expecting return within {0}ms", timeOut.TotalMilliseconds));
                }
                return -1;
            }
            List<List<TransactionEvent>> failedTransactions;
            if (failIfNone)
                failedTransactions = new List<List<TransactionEvent>>();
            else
                failedTransactions = null;
            int index = 0;
            foreach (ExpectedReturn expectedReturn in expected)
            {
                if (expectedReturn.Method == availableReturn.Method && expectedReturn.Target == availableReturn.Target)
                {                    
                    BeginTransaction();
                    try
                    {
                        TestManagerHelpers.CallChecker(expectedReturn.callingStyle, expectedReturn.Checker,
                                                    availableReturn.Target, availableReturn.Parameters);
                        EndTransaction(true);
                        ConsumeReturn();
                        return index;
                    }
                    catch (TransactionFailedException)
                    {
                        if (failIfNone)
                        {
                            failedTransactions.Add(transaction);
                        }
                        EndTransaction(false);
                    }
                }
                index++;
            }
            if (!failIfNone)
                return -1;

            // build diagnosis
            StringBuilder diagnosis = new StringBuilder();
            index = 0;
            int transactionIndex = 0;
            foreach (ExpectedReturn expectedReturn in expected)
            {
                if (expectedReturn.Method != availableReturn.Method || expectedReturn.Target != availableReturn.Target)
                {
                    diagnosis.AppendLine(String.Format("  {0}. {1} is not matching", 
                            index+1, expectedReturn.ToString()));
                }
                else
                {
                    List<TransactionEvent> t = failedTransactions[transactionIndex++];
                    diagnosis.AppendLine(String.Format("  {0}. outputs do not match", 
                                        index+1));
                    Describe(diagnosis, "    ", t);
                }
                index++;
            }
            InternalAssert(false, String.Format("expected matching return, found {0}. Diagnosis:\r\n{1}",
                            availableReturn.ToString(), diagnosis.ToString()));
            return -1;
        }


        /// <summary>
        /// Selects one satisfied pre-constraint from one or more given preconstraints described by patterns.
        /// </summary>   
        /// <param name="printDiagnosisIfFail">Behavior on failure.</param>
        /// <param name="expected">Expected pre constraints</param>
        /// <returns>
        ///  Returns index of the first preconstraint which satisfies.
        ///  if none of the pre-constraints satisfies, returns -1 if <c>failIfNone</c> is false, otherwise
        ///  produces test failure with corresponding diagnostics.
        /// </returns>
        public virtual int SelectSatisfiedPreConstraint(bool printDiagnosisIfFail, params ExpectedPreConstraint[] expected)
        {
            List<List<TransactionEvent>> failedTransactions;
            if (printDiagnosisIfFail)
                failedTransactions = new List<List<TransactionEvent>>();
            else
                failedTransactions = null;
            int index = 0;
            foreach (ExpectedPreConstraint expectedPreConstraint in expected)
            {
                BeginTransaction();
                
                try
                {
                    try
                    {
                        expectedPreConstraint.Checker.DynamicInvoke(new object[0]);
                    }
                    catch (TargetInvocationException e)
                    {
                        throw e.InnerException;
                    }

                    EndTransaction(true);
                    return index;
                }
                catch (TransactionFailedException)
                {
                    if (printDiagnosisIfFail)
                    {
                        failedTransactions.Add(transaction);
                    }
                    EndTransaction(false);
                }
                index++;
            }
            if (!printDiagnosisIfFail)
                return -1;
                       
            StringBuilder diagnosis = new StringBuilder();
            diagnosis.AppendLine("None of the expected pre-constraints are matched.");
            foreach (List<TransactionEvent> failedTransactionEvents in failedTransactions)
            {
                Describe(diagnosis, "    ", failedTransactionEvents);
            }

            site.Comment(diagnosis.ToString());
            return -1;
            
        }

        static void Describe(StringBuilder sb, string prefix, List<TransactionEvent> transaction)
        {
            foreach (TransactionEvent te in transaction)
            {
                switch (te.Kind)
                {
                    case TransactionEventKind.Assert:
                    case TransactionEventKind.Assume:
                        sb.Append(prefix);
                        if (te.Kind == TransactionEventKind.Assert)
                            sb.Append("assert ");
                        else
                            sb.Append("assume ");
                        if (te.condition)
                            sb.Append(" succeeded: ");
                        else
                            sb.Append(" failed: ");
                        sb.AppendLine(te.description);
                        break;
                    case TransactionEventKind.Checkpoint:
                        sb.Append(prefix);
                        sb.Append("checkpoint: ");
                        sb.AppendLine(te.description);
                        break;
                    case TransactionEventKind.Comment:
                        sb.Append(prefix);
                        sb.Append("comment: ");
                        sb.AppendLine(te.description);
                        break;
                    case TransactionEventKind.VariableBound:
                        sb.Append(prefix);
                        sb.AppendLine(String.Format("bound variable {0} to value: {1} ",
                                                    te.variable.Name, te.variable.ObjectValue));
                        break;
                }
            }
        }

       
        
        #endregion

        #region Test Execution

        /// <summary>
        /// Begins executing a test case.
        /// </summary>
        /// <param name="name"></param>
        public virtual void BeginTest(string name)
        {
            if (inTransaction)
            {
                transaction.Add(new TransactionEvent(TransactionEventKind.Checkpoint, true, "Begin Test: " + name, null));
            }
            else
                site.BeginTest(name);
        }

        /// <summary>
        /// Ends executing a test case.
        /// </summary>
        public virtual void EndTest()
        {
            if (inTransaction)
            {
                transaction.Add(new TransactionEvent(TransactionEventKind.Checkpoint, true, "End Test.", null));
            }
            else
                site.EndTest();
        }

        /// <summary>
        /// Executes a test assertion.
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="description"></param>
        public virtual void Assert(bool condition, string description)
        {
            if (inTransaction)
            {
                transaction.Add(new TransactionEvent(TransactionEventKind.Assert, condition, description, null));

                bool failed = !condition;
                IBypassingTestSite site2 = site as IBypassingTestSite;
                if (site2 != null)
                    failed = !site2.IsTrue(condition, description);

                if (failed)
                    throw new TransactionFailedException();
            }
            else
                InternalAssert(condition, description);
        }

        private void InternalAssert(bool condition, string description)
        {
            if (!condition && ThrowTestFailureException)
                throw new TestFailureException(description);
            else
                site.Assert(condition, description);
        }

        /// <summary>
        /// Executes a test assumption.
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="description"></param>
        public void Assume(bool condition, string description)
        {
            if (inTransaction)
            {
                transaction.Add(new TransactionEvent(TransactionEventKind.Assume, condition, description, null));
                if (!condition)
                    throw new TransactionFailedException();
            }
            else
                site.Assume(condition, description);        
        }

        /// <summary>
        /// Executes a checkpoint.
        /// </summary>
        /// <param name="description"></param>
        public void Checkpoint(string description)
        {
            if (inTransaction)
            {
                transaction.Add(new TransactionEvent(TransactionEventKind.Checkpoint, true, description, null));
            }
            else
                site.Checkpoint(description);
        }

        /// <summary>
        /// Logs a comment about test execution.
        /// </summary>
        /// <param name="description"></param>
        public void Comment(string description)
        {
            if (inTransaction)
            {
                transaction.Add(new TransactionEvent(TransactionEventKind.Comment, true, description, null));
            }
            else
                site.Comment(description);
        }

        /// <summary>
        /// Upon observation timeout, checks current event observation queue status and decides 
        /// whether case should pass or fail.
        /// </summary>
        /// <param name="isAcceptingState"></param>
        /// <param name="expected"></param>
        public void CheckObservationTimeout(bool isAcceptingState, params ExpectedEvent[] expected)
        {
            bool queueEmpty = eventQueue.GetEnumerator().Count == 0;
            if (isAcceptingState && queueEmpty)
            {
                // empty queue at an accepting state, pass case
                StringBuilder diag = new StringBuilder();
                diag.AppendLine("Observation timeout while expecting events:");
                foreach (var e in expected)
                {
                    diag.AppendLine("\t" + e.ToString());
                }
                site.Comment(diag.ToString());
                return;
            }
            else
            {
                StringBuilder diag = new StringBuilder();
                diag.AppendLine("Expected event didn't come within configured timeout.");
                
                diag.AppendLine("Expected events:");
                foreach (var e in expected)
                {
                    diag.AppendLine("\t" + e.ToString());
                }
                
                diag.AppendLine("Observed events:");
                foreach (var o in eventQueue.GetEnumerator())
                {
                    diag.AppendLine("\t" + o.ToString());
                }

                InternalAssert(false, diag.ToString());
            }
        }

        #endregion

        #region Transactions and Variables

        /// <summary>
        /// Creates a new variable which can be transacted.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="name"></param>
        /// <returns></returns>
        public virtual IVariable<T> CreateVariable<T>(string name)
        {
            return new Variable<T>(name, this);
        }

        /// <summary>
        /// Generates a default value of type T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public virtual T GenerateValue<T>()
        {
            return default(T);
        }

        /// <summary>
        /// Random seed for value generation.
        /// </summary>
        public int RandomSeed
        {
            get { return randomSeed; }
            set { randomSeed = value; }
        }

        /// <summary>
        /// Begins a transaction. Note that the execution of a Checker happens implicitly within a transaction.
        /// </summary>
        public virtual void BeginTransaction()
        {
            if (inTransaction)
                throw new InvalidOperationException("nested test manager transactions not allowed");
            transaction = new List<TransactionEvent>();
        }

        /// <summary>
        /// Ends transaction, either committing variables which have been bound, or rolling them back. 
        /// Note that the execution of a Checker happens implicitly within a transaction.
        /// </summary>
        /// <param name="commit"></param>
        public void EndTransaction(bool commit)
        {
            if (!inTransaction)
                throw new InvalidOperationException("no test manager transaction active which can be ended");
            if (commit)
            {
                foreach (TransactionEvent te in transaction)
                {
                    switch (te.Kind)
                    {
                        case TransactionEventKind.Assert:
                            site.Assert(te.condition, te.description);
                            break;
                        case TransactionEventKind.Assume:
                            site.Assume(te.condition, te.description);
                            break;
                        case TransactionEventKind.Checkpoint:
                            site.Checkpoint(te.description);
                            break;
                        case TransactionEventKind.Comment:
                            site.Comment(te.description);
                            break;
                        case TransactionEventKind.VariableBound:
                            site.Comment(String.Format("bound variable {0} to value: {1} ",
                                                    te.variable.Name, te.variable.ObjectValue));
                            break;
                    }
                }
            }
            else
            {
                // unroll variable bindings
                foreach (TransactionEvent te in transaction)
                    if (te.Kind == TransactionEventKind.VariableBound)
                        te.variable.InternalUnbind();
            }
            transaction = null;
        }

        #endregion

        /// <summary>
        /// if true, throw predefined <see cref="TestFailureException"/> when assertion fails and dynamic traversal
        /// can catch it and decide how to proceed.
        /// Otherwise, leaves to test control manager to handle assertion failure.
        /// </summary>
        public bool ThrowTestFailureException { get; set; }

    }
}
