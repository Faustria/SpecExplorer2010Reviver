﻿using System;

namespace Microsoft.SpecExplorer.Runtime.Testing
{
    /// <summary>
    /// An attribute which indicates to the Spec Explorer test code infrastructure
    /// that a given class or interface and all its derivations represents a test adapter.
    /// </summary>
    [AttributeUsage(AttributeTargets.Interface | AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public sealed class TestAdapterAttribute : Attribute
    { }
}

