﻿using System;

namespace Microsoft.SpecExplorer.Runtime.Testing
{

    /// <summary>
    /// An exception which is thrown when assertion failure is hit.
    /// </summary>
    [Serializable]
    public class TestFailureException : Exception
    {
        /// <summary>
        /// Constructs the TestFailureException.
        /// </summary>
        public TestFailureException()
            : base()
        { }

        /// <summary>
        /// Constructs the TestFailureException.
        /// </summary>
        /// <param name="message">error message</param>
        public TestFailureException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Constructs the TestFailureException.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="innerException">The inner exception.</param>
        public TestFailureException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

#if !COMPACT
        /// <summary>
        /// Constructs the TestFailureException.
        /// </summary>
        /// <param name="serializationInfo"></param>
        /// <param name="streamingContext"></param>
        protected TestFailureException(System.Runtime.Serialization.SerializationInfo serializationInfo, System.Runtime.Serialization.StreamingContext streamingContext)
            : base(serializationInfo, streamingContext)
        {
        }
#endif
    }
}
