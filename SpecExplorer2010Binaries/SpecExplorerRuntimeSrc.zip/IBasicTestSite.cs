using System;

namespace Microsoft.SpecExplorer.Runtime.Testing
{
    /// <summary>
    /// Represents basic functionality required by the test manager from the test site.
    /// </summary>
    public interface IBasicTestSite
    {
        /// <summary>
        /// Retrieves singleton instance of an adapter of the given type; throws exception on failure.
        /// </summary>
        /// <param name="adapterType"></param>
        /// <returns></returns>
        object GetAdapter(Type adapterType);

        /// <summary>
        /// Begins executing a test case.
        /// </summary>
        /// <param name="name"></param>
        void BeginTest(string name);

        /// <summary>
        /// Ends executing a test case.
        /// </summary>
        void EndTest();

        /// <summary>
        /// Executes a test assertion.
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="description"></param>
        void Assert(bool condition, string description);

        /// <summary>
        /// Executes a test assumption.
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="description"></param>
        void Assume(bool condition, string description);

        /// <summary>
        /// Executes a checkpoint.
        /// </summary>
        /// <param name="description"></param>
        void Checkpoint(string description);

        /// <summary>
        /// Logs a comment about test execution.
        /// </summary>
        /// <param name="description"></param>
        void Comment(string description);

    }

    /// <summary>
    /// Extends IsTrue interface which check condition together with description to by-pass assertion failure.
    /// </summary>
    public interface IBypassingTestSite: IBasicTestSite
    {
        /// <summary>
        /// Check condition together with description to by-pass assertion failure. It returns false if and only if condition is false and description is not by-passed.
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="description"></param>
        /// <returns></returns>
        bool IsTrue(bool condition, string description);
    }
}
