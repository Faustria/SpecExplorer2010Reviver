﻿using System;
using System.Collections.Generic;

namespace Microsoft.SpecExplorer.Runtime.Testing
{
    /// <summary>
    /// Interface to be implemented by classes used as base class
    /// of generated test suite
    /// </summary>
    public interface IGeneratedTestClass
    {
        /// <summary>
        /// Sets a switch.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="value"></param>
        void SetSwitch(string name, string value);

        /// <summary>
        /// Gets or sets quiescence timeout. Is initialized from switch.
        /// </summary>
        TimeSpan QuiescenceTimeout { get; set; }

        /// <summary>
        /// Gets or sets proceed control timeout. Is initialized from switch.
        /// </summary>
        TimeSpan ProceedControlTimeout { get; set; }

        /// <summary>
        /// Initializes the test manager. Implementation can instantiate 
        /// <see cref="DefaultTestManager"/>, unless one wants to implement
        /// a completely new test manager.
        /// </summary>
        void InitializeTestManager();

        /// <summary>
        /// Cleans up the test manager.
        /// </summary>
        void CleanupTestManager();

        /// <summary>
        /// Returns the test manager. Only valid after initialization and before cleanup.
        /// </summary>
        ITestManager Manager { get; set;}

        /// <summary>
        /// Creates a Struct of type T with given field initialization.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="fieldNames"></param>
        /// <param name="fieldValues"></param>
        /// <returns></returns>
        T Make<T>(string[] fieldNames, object[] fieldValues);
    }

    /// <summary>
    /// a test class enables configuring test properties at runtime.
    /// </summary>
    public interface IConfigurableGeneratedTestClass : IGeneratedTestClass
    {        
        /// <summary>
        /// Return test properties set up for this test class.
        /// </summary>
        IDictionary<string, string> TestProperties { get; set; }

        /// <summary>
        /// whether log comment/checkpoint into file.
        /// </summary>
        bool LogToFile { get; set; }

    }
}
