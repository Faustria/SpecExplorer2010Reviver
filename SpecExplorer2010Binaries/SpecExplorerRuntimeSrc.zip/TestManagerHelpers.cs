using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.Serialization;
using Microsoft.Modeling;
using System.Globalization;

#if !COMPACT

using System.Reflection.Emit;

#endif

namespace Microsoft.SpecExplorer.Runtime.Testing
{
    /// <summary>
    /// Helpers for dealing with test managers.
    /// </summary>
    public static class TestManagerHelpers
    {
        static Dictionary<Type, bool> adapterTypes = new Dictionary<Type, bool>();

        /// <summary>
        /// Checks whether a given type represents a test adapter.
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static bool IsAdapter(Type type)
        {
            bool isAdapter;

            lock (adapterTypes)
            {
                if (!adapterTypes.TryGetValue(type, out isAdapter))
                {
                    object[] attrs = type.GetCustomAttributes(typeof(TestAdapterAttribute), true);
                    isAdapter = (attrs != null && attrs.Length > 0);

                    if (!isAdapter)
                    {
                        foreach (Type intf in type.GetInterfaces())
                        {
                            if (IsAdapter(intf))
                            {
                                isAdapter = true;
                                break;
                            }
                        }

                        if (!isAdapter && type.BaseType != null)
                        {
                            isAdapter = IsAdapter(type.BaseType);
                        }
                    }

                    adapterTypes[type] = isAdapter;
                }
            }

            return isAdapter;
        }

        /// <summary>
        /// Subscribes all public events of a given object to the test manager.
        /// </summary>
        /// <param name="manager"></param>
        /// <param name="adapter"></param>
        public static void Subscribe(ITestManager manager, object adapter)
        {
            BindingFlags flags = adapter == null ? BindingFlags.Static : BindingFlags.Instance;
            if (adapter != null)
            {
                foreach (EventInfo eventInfo in adapter.GetType().GetEvents(BindingFlags.Public | BindingFlags.NonPublic | flags))
                {
                    if (manager != null)
                    {
                        manager.Subscribe(eventInfo, adapter);
                    }
                }
            }
        }

        /// <summary>
        /// Unsubscribes all public events of a given object to the test manager.
        /// </summary>
        /// <param name="manager"></param>
        /// <param name="adapter"></param>
        public static void Unsubscribe(ITestManager manager, object adapter)
        {
            BindingFlags flags = adapter == null ? BindingFlags.Static : BindingFlags.Instance;
            if (adapter != null)
            {
                foreach (EventInfo eventInfo in adapter.GetType().GetEvents(BindingFlags.Public | BindingFlags.NonPublic | flags))
                {
                    if (manager != null)
                    {
                        manager.Unsubscribe(eventInfo, adapter);
                    }
                }
            }
        }
        /// <summary>
        /// Describes a value for test diagnostics.
        /// </summary>
        /// <param name="value">Value object</param>
        /// <returns>String who describes the value</returns>
        public static string Describe(object value)
        {
            // check for null;
            if (value == null) return "null";
            
            return Microsoft.Xrt.Runtime.RuntimeSupport.Describe <object> (value);
        }

        /// <summary>
        /// Gets the parameter types of a delegate.
        /// </summary>
        /// <param name="delegateType"></param>
        /// <returns></returns>
        internal static Type[] GetDelegateParameterTypes(Type delegateType)
        {
            if (!typeof(Delegate).IsAssignableFrom(delegateType))
                throw new InvalidOperationException("not a delegate type");
            return GetMethodParameterTypes(delegateType.GetMethod("Invoke"));
        }

        /// <summary>
        /// Gets the parameter types of a method.
        /// </summary>
        /// <param name="methodInfo"></param>
        /// <returns></returns>
        internal static Type[] GetMethodParameterTypes(MethodBase methodInfo)
        {
            ParameterInfo[] paramInfos = methodInfo.GetParameters();
            Type[] result = new Type[paramInfos.Length];
            for (int i = 0; i < result.Length; i++)
                result[i] = paramInfos[i].ParameterType;
            return result;
        }

        /// <summary>
        /// Checks whether an event requires a target object, which is the case
        /// when it is instance based and when it is not originating from an adapter.
        /// </summary>
        /// <param name="memberInfo">reflection member info</param>
        /// <returns></returns>
        internal static bool RequiresTarget(MemberInfo memberInfo)
        {
            bool isStatic = 
                memberInfo is MethodBase ? ((MethodBase)memberInfo).IsStatic 
                : memberInfo is EventInfo ? ((EventInfo)memberInfo).GetAddMethod().IsStatic
                : false;
            return !isStatic && !TestManagerHelpers.IsAdapter(memberInfo.DeclaringType);
        }

       
        /// <summary>
        /// Determines the way how to call a checker for an event. Calculates whether the event and checker
        /// types are compatible, and whether to include the target in the call or not.
        /// </summary>
        /// <param name="eventInfo"></param>
        /// <param name="checkerType"></param>
        /// <returns></returns>
        internal static CheckerCallingStyle GetEventCheckerCallingStyle(EventInfo eventInfo, Type checkerType)
        {
            Type handlerType = eventInfo.EventHandlerType;
            if (checkerType == handlerType)
                return CheckerCallingStyle.ParametersDirect;
            Type[] eventArguments = GetDelegateParameterTypes(handlerType);
            Type[] checkerArguments = GetDelegateParameterTypes(checkerType);
            if (checkerArguments.Length == 1 && checkerArguments[0] == typeof(object))
                if (RequiresTarget(eventInfo))
                    return CheckerCallingStyle.TargetAndParametersArray;
                else
                    return CheckerCallingStyle.ParametersArray;
            int offset = 0;
            CheckerCallingStyle style = CheckerCallingStyle.ParametersDirect;
            if (checkerArguments.Length == eventArguments.Length + 1)
            {
                if (!RequiresTarget(eventInfo) || checkerArguments[0] != eventInfo.DeclaringType)
                    return CheckerCallingStyle.Invalid;
                offset = 1;
                style = CheckerCallingStyle.TargetAndParametersDirect;
            }
            for (int i = 0; i < eventArguments.Length; i++)
                if (eventArguments[i] != checkerArguments[offset + i])
                    return CheckerCallingStyle.Invalid;
            return style;
        }

        /// <summary>
        /// Determines the way how to call a checker for a return method event. Calculates whether the method and checker
        /// types are compatible, and whether to include the target in the call or not.
        /// </summary>
        /// <param name="methodInfo"></param>
        /// <param name="checkerType"></param>
        /// <returns></returns>
        internal static CheckerCallingStyle GetReturnCheckerCallingStyle(MethodBase methodInfo, Type checkerType)
        {

            Type[] checkerArguments = GetDelegateParameterTypes(checkerType);
            if (checkerArguments.Length == 1 && checkerArguments[0] == typeof(object))
                if (RequiresTarget(methodInfo))
                    return CheckerCallingStyle.TargetAndParametersArray;
                else
                    return CheckerCallingStyle.ParametersArray;
            int offset = 0;
            CheckerCallingStyle style = CheckerCallingStyle.ParametersDirect;
            List<Type> methodOutputs = new List<Type>();
            Type returnType;
            if (methodInfo is MethodInfo)
                returnType = ((MethodInfo)methodInfo).ReturnType;
            else
                returnType = null;
            
            foreach (ParameterInfo info in methodInfo.GetParameters())
            {
                if (info.ParameterType.IsByRef)
                    methodOutputs.Add(info.ParameterType.GetElementType());
            }

            //resultType should be reordered after method parameters
            if (returnType != null && returnType != typeof(void))
                methodOutputs.Add(returnType);

            if (checkerArguments.Length == methodOutputs.Count + 1)
            {
                if (!RequiresTarget(methodInfo) || checkerArguments[0] != methodInfo.DeclaringType)
                    return CheckerCallingStyle.Invalid;
                offset = 1;
                style = CheckerCallingStyle.TargetAndParametersDirect;
            }
            for (int i = 0; i < methodOutputs.Count; i++)
                if (methodOutputs[i] != checkerArguments[offset + i])
                    return CheckerCallingStyle.Invalid;
            return style; 
        }

        /// <summary>
        /// Calls a checker according to the given calling style.
        /// </summary>
        /// <param name="style"></param>
        /// <param name="checker"></param>
        /// <param name="target"></param>
        /// <param name="parameters"></param>
        internal static void CallChecker(CheckerCallingStyle style, Delegate checker, object target, object[] parameters)
        {
            object[] allparams; 
            switch (style)
            {
                case CheckerCallingStyle.ParametersDirect:
                case CheckerCallingStyle.ParametersArray:
                    allparams = parameters;
                    break;
                case CheckerCallingStyle.TargetAndParametersDirect:
                case CheckerCallingStyle.TargetAndParametersArray:
                    allparams = new object[parameters.Length+1];
                    allparams[0] = target;
                    parameters.CopyTo(allparams, 1);
                    break;
                default:
                    throw new InvalidOperationException("invalid calling style");
            }
            try
            {
                switch (style)
                {
                    case CheckerCallingStyle.ParametersDirect:
                    case CheckerCallingStyle.TargetAndParametersDirect:
                        checker.DynamicInvoke(allparams);
                        break;
                    default:
                        checker.DynamicInvoke(new object[] { allparams });
                        break;
                }
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }
        }
        
        /// <summary>
        /// A delegate type representing a generic event handler.
        /// </summary>
        /// <param name="eventInfo"></param>
        /// <param name="target"></param>
        /// <param name="parameters"></param>
        internal delegate void GenericEventHandler(EventInfo eventInfo, object target, object[] parameters);

        /// <summary>
        /// Generates a delegate object which matches the given event info's type and
        /// calls the generic event processor.
        /// </summary>
        /// <param name="eventInfo">The event info for which to generate a matching delegate.</param>
        /// <param name="target">The target instance.</param>
        /// <param name="processor">The generic event processor to be called.</param>
        /// <returns></returns>
        internal static Delegate Generate(EventInfo eventInfo, object target, GenericEventHandler processor)
        {
#if !COMPACT

            // Create assembly builder and type builder
            string name = "handler_" + eventInfo.Name;
            AssemblyBuilder assBuilder =
                AppDomain.CurrentDomain.DefineDynamicAssembly(new AssemblyName(name), AssemblyBuilderAccess.Run);
            ModuleBuilder moduleBuilder = assBuilder.DefineDynamicModule(name);
            TypeBuilder typeBuilder = moduleBuilder.DefineType(name, TypeAttributes.Public | TypeAttributes.Class);

            // Create field to remember event info and processor delegate
            FieldBuilder eventInfoField =
                typeBuilder.DefineField("eventInfo", typeof(EventInfo), FieldAttributes.Public);
            FieldBuilder targetField =
                typeBuilder.DefineField("target", typeof(object), FieldAttributes.Public);
            FieldBuilder processorField =
                typeBuilder.DefineField("processor", typeof(GenericEventHandler),
                                        FieldAttributes.Public);

            // Create method builder
            Type handlerType = eventInfo.EventHandlerType;
            MethodInfo invoke = handlerType.GetMethod("Invoke");
            ParameterInfo[] paramInfos = invoke.GetParameters();
            Type[] paramTypes = new Type[paramInfos.Length];
            for (int i = 0; i < paramTypes.Length; i++)
                paramTypes[i] = paramInfos[i].ParameterType;

            MethodBuilder methodBuilder = typeBuilder.DefineMethod("m_" + eventInfo.Name,
                                                MethodAttributes.Public,
                                                invoke.ReturnType, paramTypes);
            // Generate code
            ILGenerator gen = methodBuilder.GetILGenerator();

            // load processor delegate
            gen.Emit(OpCodes.Ldarg_0);
            gen.Emit(OpCodes.Ldfld, processorField); // this.processor

            // create outer parameter array
            gen.Emit(OpCodes.Ldc_I4, 3);
            gen.Emit(OpCodes.Newarr, typeof(object));
            gen.Emit(OpCodes.Dup);
            gen.Emit(OpCodes.Ldc_I4, 0);
            gen.Emit(OpCodes.Ldarg_0);
            gen.Emit(OpCodes.Ldfld, eventInfoField); // this.eventInfo
            gen.Emit(OpCodes.Stelem, typeof(object));

            gen.Emit(OpCodes.Dup);
            gen.Emit(OpCodes.Ldc_I4, 1);
            gen.Emit(OpCodes.Ldarg_0);
            gen.Emit(OpCodes.Ldfld, targetField); // this.target
            gen.Emit(OpCodes.Stelem, typeof(object));

            // create inner parameter 
            gen.Emit(OpCodes.Dup);
            gen.Emit(OpCodes.Ldc_I4, 2);
            gen.Emit(OpCodes.Ldc_I4, paramTypes.Length);
            gen.Emit(OpCodes.Newarr, typeof(object));
            for (int i = 0; i < paramTypes.Length; i++)
            {
                gen.Emit(OpCodes.Dup);
                gen.Emit(OpCodes.Ldc_I4, i);
                gen.Emit(OpCodes.Ldarg, (short)(i + 1));
                if (paramTypes[i].IsValueType)
                {
                    // box
                    gen.Emit(OpCodes.Box, paramTypes[i]);
                }
                gen.Emit(OpCodes.Stelem, typeof(object));
            }
            gen.Emit(OpCodes.Stelem, typeof(object));

            // call processor delegate
            MethodInfo invokeProcessor = typeof(Delegate).GetMethod("DynamicInvoke");
            gen.EmitCall(OpCodes.Callvirt, invokeProcessor, null);
            gen.Emit(OpCodes.Pop);

            gen.Emit(OpCodes.Ret);


            // create delegate
            Type builtType = typeBuilder.CreateType();


            object builtInstance = Activator.CreateInstance(builtType);
            builtType.GetField("eventInfo").SetValue(builtInstance, eventInfo);
            builtType.GetField("processor").SetValue(builtInstance, processor);
            builtType.GetField("target").SetValue(builtInstance, target);

            return Delegate.CreateDelegate(handlerType, builtInstance, methodBuilder.Name);
#else
            throw new NotImplementedException("This method should not be executed under CLR on compact framework.");
#endif
        }

#if COMPACT

        /// <summary>
        /// Invoke delegate method.
        /// </summary>
        /// <param name="delegate"></param>
        /// <param name="parameters"></param>
        public static void DynamicInvoke(this Delegate @delegate, object[] parameters)
        {
            @delegate.Method.Invoke(@delegate.Target, parameters);
        }

#endif

        /// <summary>
        /// Replace the internal generic processor of the given event handler
        /// </summary>
        /// <param name="eventHandler"></param>
        /// <param name="newProcessor"></param>
        internal static void UpdateEventHandlerProcessor(Delegate eventHandler, GenericEventHandler newProcessor)
        {
            if (eventHandler == null || eventHandler.Method == null)
            {
                return;
            }

            Type declType = eventHandler.Method.DeclaringType;
            FieldInfo processorField = declType.GetField("processor");
            if (processorField == null)
            {
                return;
            }
            
            processorField.SetValue(eventHandler.Target, newProcessor);
        }

        /// <summary>
        /// Gets an object's field value by field name through reflection
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static object GetFieldValueByName(object obj, string fieldName)
        {
            if (obj == null)
            {
                throw new ArgumentNullException("obj");
            }
            FieldInfo[] fields =
                obj.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);

            for (int i = 0; i < fields.Length; i++)
            {
                if (fields[i].Name == fieldName)
                {
                    return fields[i].GetValue(obj);
                }
            }
                
            throw new ArgumentException(String.Format("Field {0} doesn't exist", fieldName), "fieldName");
        }

        /// <summary>
        /// Creates a struct or compound value of type T with given field initialization.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="fields"></param>
        /// <returns></returns>
        public static T Make<T>(IDictionary<FieldInfo, object> fields)
        {
            Type type = typeof(T);

            object x;
            try
            {
                //first try to create instance with default constructor
                x = Activator.CreateInstance(type);
            }
 #if COMPACT
            catch (MissingMethodException e)
            {

                throw new InvalidOperationException(
                    String.Format("Cannot create instance for type '{0}' because there is no parameter-less constructor declared for it", type.FullName), e);
            }
#else
            catch (MissingMethodException)
            {
                //if type doesn't define parameter less constructor, create instance without calling constructor.
                x = FormatterServices.GetUninitializedObject(type);
            }
#endif
            //initialize all fields.
            foreach (FieldInfo field in fields.Keys)
            {
                object fieldValue;
                if (field.FieldType.IsEnum)
                {
                    fieldValue = Enum.ToObject(field.FieldType, fields[field]);
                }
                else
                {
                    fieldValue = Convert.ChangeType(fields[field], field.FieldType, CultureInfo.CurrentCulture);
                }
                field.SetValue(x, fieldValue);
            }
            return (T)x;
        }

        #region Reflection helpers

        /// <summary>
        /// Return method info for given meta-data information. Throws exception if method cannot be resolved.
        /// </summary>
        /// <param name="type"></param>
        /// <param name="name"></param>
        /// <param name="parameterTypes"></param>
        /// <returns></returns>
        public static MethodInfo GetMethodInfo(Type type, string name, params Type[] parameterTypes)
        {
            if (type == null)
            {
                throw new ArgumentNullException("type");
            }
            MethodInfo info = type.GetMethod(name,
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static,
                null, parameterTypes, null);
            if (info == null)
                throw new InvalidOperationException(String.Format("Cannot resolve method '{0}' in type '{1}'",
                                                                    name, type));
            return info;
        }

        /// <summary>
        /// Return constructor for given meta-data information. Throws exception if constructor cannot be resolved.
        /// </summary>
        /// <param name="type"></param>
        /// <param name="parameterTypes"></param>
        /// <returns></returns>
        public static ConstructorInfo GetConstructorInfo(Type type, params Type[] parameterTypes)
        {
           if (type == null)
           {
               throw new ArgumentNullException("type");
           }
           ConstructorInfo info = type.GetConstructor(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance, null,
                                    parameterTypes, null);
            if (info == null)
                throw new InvalidOperationException(String.Format("Cannot resolve constructor for type '{0}'",
                                                                    type));
            return info;
        }


        /// <summary>
        /// Return event for given meta-data information. Throws exception if event cannot be resolved.
        /// </summary>
        /// <param name="type"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static EventInfo GetEventInfo(Type type, string name)
        {
            if (type == null)
            {
                throw new ArgumentNullException("type");
            }
            EventInfo info = type.GetEvent(name,
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static);
            if (info == null)
                throw new InvalidOperationException(String.Format("Cannot resolve event '{0}' for type '{1}'",
                                                                name, type));
            return info;
        }

        #endregion

        #region Equality Helper

        /// <summary>
        /// Equality helper class to compare whether two objects are equal.
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns></returns>
        public static bool Equality(object left, object right)
        {
            if (left == null && right == null)
                return true;
            else if (left == null || right == null)
                return false;
            Type leftType = left.GetType();
            Type rightType = right.GetType();
            if (leftType == rightType)
            {
                if ((leftType.IsClass && !typeof(CompoundValue).IsAssignableFrom(leftType)))
                    return Object.ReferenceEquals(left, right);                
                else 
                    return left.Equals(right);
            }
            else
            {
                throw new NotSupportedException(string.Format("Test Manager doesn't know how to compare left {0} and right {1} value", left, right));
            }
        }       

        #endregion

        #region Assertion Helpers

        /// <summary>
        /// Asserts two values are equal.
        /// </summary>
        /// <typeparam name="T">Type of values.</typeparam>
        /// <param name="manager">The test manager.</param>
        /// <param name="expected">The expected value.</param>
        /// <param name="actual">The actual value.</param>
        /// <param name="context">The description of the context under which both values are compared.</param>
        public static void AssertAreEqual<T>(ITestManager manager, T expected, T actual, string context)
        {
            manager.Assert(Object.Equals(expected, actual), 
                string.Format("expected \'{0}\', actual \'{1}\' ({2})", 
                    Describe(expected), Describe(actual), context));
        }

        /// <summary>
        /// Asserts a variable's equality to a value or bind the variable to a value if it hasn't been bound yet.
        /// </summary>
        /// <typeparam name="T">Type of the variable and value.</typeparam>
        /// <param name="manager">The test manager.</param>
        /// <param name="var">The variable.</param>
        /// <param name="actual">The actual value.</param>
        /// <param name="context">The description of the context under which the comparison or binding happens.</param>
        public static void AssertBind<T>(ITestManager manager, IVariable<T> var, T actual, string context)
        {
            if (var.IsBound)
            {
                AssertAreEqual<T>(manager, var.Value, actual, 
                    context + "; expected value originates from previous binding");
            }
            else
            {
                var.Value = actual;
            }
        }

        /// <summary>
        /// Asserts equality of two variables, or bind one variable to another if only one of them is bound. 
        /// If neither of the two variables are bound, this API does nothing.
        /// </summary>
        /// <typeparam name="T">Type of the variables.</typeparam>
        /// <param name="manager">The test manager.</param>
        /// <param name="v1">The first variable.</param>
        /// <param name="v2">The second variable.</param>
        /// <param name="context">The context under which the comparison or binding happens.</param>
        public static void AssertBind<T>(ITestManager manager, IVariable<T> v1, IVariable<T> v2, string context)
        {
            if ((v1.IsBound && v2.IsBound))
            {
                AssertAreEqual<T>(manager, v1.Value, v2.Value, 
                    context + "; values originate from previous binding");
                return;
            }
            if (v1.IsBound)
            {
                v2.Value = v1.Value;
            }
            else
            {
                if (v2.IsBound)
                {
                    v1.Value = v2.Value;
                }
            }
        }

        /// <summary>
        /// Asserts a value is not null.
        /// </summary>
        /// <param name="manager">The test manager.</param>
        /// <param name="actual">The value under check.</param>
        /// <param name="context">The context under which the value is checked.</param>
        public static void AssertNotNull(ITestManager manager, object actual, string context)
        {
            manager.Assert(actual != null, string.Format("expected non-null value ({0})", context));
        }

        #endregion

    }
}


