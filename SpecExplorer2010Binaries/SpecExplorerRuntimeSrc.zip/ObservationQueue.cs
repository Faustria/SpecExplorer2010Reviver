using System;
using System.Collections.Generic;
using System.Threading;

namespace Microsoft.SpecExplorer.Runtime.Testing
{
    /// <summary>
    /// Implements a simple thread-safe queue used for observations like events and returns.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ObservationQueue<T>
    {
        object queueLock = new object();
        object queueFullLock = new object();
        Queue<T> queue;

        /// <summary>
        /// Constructs a queue with given maximal size.
        /// </summary>
        /// <param name="maxSize">This parameter is not effective for the current release.</param>
        public ObservationQueue(int maxSize)
        {
            this.queue = new Queue<T>(maxSize);
        }

        /// <summary>
        /// Adds an item to the queue. 
        /// </summary>
        /// <param name="item"></param>
        public void Add(T item)
        {
            // TODO: block if queue is currently full.
            lock (queueLock)
            {
                queue.Enqueue(item);
                Monitor.Pulse(queueLock);
            }
        }

        /// <summary>
        /// Try gets an item from the queue.
        /// </summary>
        /// <param name="timeOut"></param>
        /// <param name="consume"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool TryGet(TimeSpan timeOut, bool consume, out T item)
        {
            lock (queueLock)
            {
                if (queue.Count == 0)
                {
                    Monitor.Wait(queueLock, timeOut);
                    if (queue.Count == 0)
                    {
                        item = default(T);
                        return false;
                    }
                }
                if (consume)
                {
                    item = queue.Dequeue();
                }
                else
                    item = queue.Peek();
            }
            if (consume)
                lock (queueFullLock)
                    Monitor.PulseAll(queueFullLock);
            return true;
        }

        /// <summary>
        /// Returns a copy of the queue content as a list. 
        /// </summary>
        /// <returns></returns>
        public IList<T> GetEnumerator()
        {
            lock (queueLock)
                return new List<T>(queue);
        }

    }

}
