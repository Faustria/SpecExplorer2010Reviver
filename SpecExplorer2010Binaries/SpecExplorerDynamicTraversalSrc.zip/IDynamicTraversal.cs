﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SpecExplorer.Runtime.Testing;
using Microsoft.SpecExplorer.ObjectModel;

namespace Microsoft.SpecExplorer.DynamicTraversal
{
    /// <summary>
    /// The interface to describe a dynamic traversal test strategy.
    /// </summary>
    public interface IDynamicTraversal
    {
        /// <summary>
        /// In general, the strategy interacts with serialized transition system to verify SUT on the fly.
        /// </summary>
        /// <param name="transitionSystem">transition system used by traversal algorithm</param>
        /// <param name="callDelegates">a delegate dictionary which stores the delegates associate with each call transition</param>
        /// <param name="returnDelegates">a delegate dictionary which stores the delegates associate with each return transition </param>
        /// <param name="eventDelegates">a delegate dictionary which stores the delegates associate with each event transition</param>
        /// <param name="testInitialize">test manager attached to test strategy</param>
        /// <param name="testCleanup">test initialize delegate used before one new test case is started</param>
        /// <param name="testProperties">test properties for dynamic traversal which should be configured at test runtime</param>
        void RunTestSuite(TransitionSystem transitionSystem,
            IDictionary<Transition, CallTransitionDelegate> callDelegates,
            IDictionary<Transition, ReturnTransitionDelegate> returnDelegates, 
            IDictionary<Transition, EventTransitionDelegate> eventDelegates,
            TestHousekeepingHandler testInitialize, 
            TestHousekeepingHandler testCleanup,
            IDictionary<string, string> testProperties);
        
        /// <summary>
        /// Gets or sets quiescence timeout. Is initialized from switch.
        /// </summary>
        TimeSpan QuiescenceTimeout { get; set; }

        /// <summary>
        /// Gets or sets proceed control timeout. Is initialized from switch.
        /// </summary>
        TimeSpan ProceedControlTimeout { get; set; }

        /// <summary>
        /// Gets or sets test manager. Is initialized by TestInitialize handler.
        /// </summary>
        ITestManager Manager { get; set; }
        
    }

    /// <summary>
    /// A delegate used for test initialize and test cleanup.
    /// </summary>
    public delegate void TestHousekeepingHandler();

    /// <summary>
    /// A delegate to represent a call invoke to SUT
    /// </summary>
    public delegate void CallTransitionDelegate();

    /// <summary>
    /// A delegate to represent a return check received from SUT.
    /// </summary>
    /// <returns></returns>
    public delegate ExpectedReturn ReturnTransitionDelegate();

    /// <summary>
    /// A delegate to represent an event check received from SUT.
    /// </summary>
    /// <returns></returns>
    public delegate ExpectedEvent EventTransitionDelegate();

}
