﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SpecExplorer.ObjectModel;
using Microsoft.SpecExplorer.Runtime.Testing;

namespace Microsoft.SpecExplorer.DynamicTraversal
{
    /// <summary>
    /// A coverage dynamic traversal.
    /// </summary>
    public abstract class CoverageDynamicTraversal: DynamicTraversalBase
    {
        /// <summary>
        /// Dictionary stores state coverage information.
        /// </summary>
        protected Dictionary<State, int> stateCoverageCounterDict = new Dictionary<State, int>();

        /// <summary>
        /// Dictionary stores transition coverage information.
        /// </summary>
        protected Dictionary<Transition, int> transitionCoverageCounterDict = new Dictionary<Transition, int>();

        private int coveredStates = 0;
        private int coveredTransitions = 0;

        /// <summary>
        /// The constructor.
        /// </summary>
        protected CoverageDynamicTraversal() : base()
        {
            StateReached += new StateNotificationHandler(CoverState);
            TransitionTaken += new StepNotificationHandler(CoverTransition);
        }

        /// <summary>
        /// The event handler when a state is covered.
        /// </summary>
        /// <param name="state"></param>
        protected void CoverState(State state)
        {
            int counter;
            if (!stateCoverageCounterDict.TryGetValue(state, out counter))
            {
                stateCoverageCounterDict[state] = 1;
            }
            else
            {
                counter++;
                stateCoverageCounterDict[state] = counter;
            }
            coveredStates++;
            this.Manager.Comment(string.Format("reaching state {0}", state.Label));
        }

        /// <summary>
        /// The event handler when a transition is taken
        /// </summary>
        /// <param name="transition"></param>
        protected void CoverTransition(Transition transition)
        {
            int counter;
            if (!transitionCoverageCounterDict.TryGetValue(transition, out counter))
            {
                transitionCoverageCounterDict[transition] = 1;
            }
            else
            {
                counter++;
                transitionCoverageCounterDict[transition] = counter;
            }
            coveredTransitions++;
        }
    }

    /// <summary>
    /// A random coverage dynamic traversal.
    /// </summary>
    public class RandomCoverageDynamicTraversal: CoverageDynamicTraversal
    {
        private const int defaultRandomSeed = 100;
        private Random random = new System.Random(defaultRandomSeed);

        private TimeSpan? timeout;
 
        /// <summary>
        /// The constructor.
        /// </summary>
        public RandomCoverageDynamicTraversal ()
            : base()
        { 
        }

        /// <summary>
        /// Choose an initial state from transition system
        /// </summary>
        /// <returns></returns>
        public override State ChooseInitialState()
        {
            State[] unCoveredStates = transitionSystem.InitialStates.Select(s => transitionSystem.GetStateFromLabel(s))
                .Where(t =>
            {
                int counter;
                if (stateCoverageCounterDict.TryGetValue(t, out counter) && counter > 0)
                    return false;
                else
                    return true;
            }).Select(t => t).ToArray();

            State[] coveredStates = transitionSystem.InitialStates.Select(s => transitionSystem.GetStateFromLabel(s))
                .Where(t =>
            {
                int counter;
                if (stateCoverageCounterDict.TryGetValue(t, out counter) && counter > 0)
                    return true;
                else
                    return false;
            }).Select(t => t).ToArray();

            if (unCoveredStates.Length > 0)
            {
                int index = random.Next(unCoveredStates.Length);
                return unCoveredStates[index];
            }
            else if (coveredStates.Length > 0)
            {
                int index = random.Next(coveredStates.Length);
                return coveredStates[index];
            }
            else
                return null;
        }

        /// <summary>
        /// Choose a controllable transition.
        /// </summary>
        /// <returns></returns>
        public override Transition ChooseControllableTransition(State state, IList<Transition> transition)
        {
            Transition[] uncoveredTransitions = transition.Where(t =>
            {
                int value;
                if (transitionCoverageCounterDict.TryGetValue(t, out value) && value > 0)
                    return false;
                else
                    return true;
            }).Select(t => t).ToArray();

            Transition[] coveredTransitions = transition.Where(t =>
            {
                int value;
                if (transitionCoverageCounterDict.TryGetValue(t, out value) && value > 0)
                    return true;
                else
                    return false;
            }).Select(t => t).ToArray();

            if (uncoveredTransitions.Length > 0)
            {
                int index = random.Next(uncoveredTransitions.Count());
                return uncoveredTransitions[index];
            }
            else if (coveredTransitions.Length > 0)
            {
                int index = random.Next(coveredTransitions.Count());
                return coveredTransitions[index];
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Stop test case only at end state.
        /// </summary>
        /// <param name="acceptingState"></param>
        /// <returns></returns>
        public override bool ShouldStopTestCaseAt(State acceptingState)
        {
            List<Transition> transitions;
            if (transitionSystem.TryGetOutgoingTransitions(acceptingState, out transitions)
                && transitions.Count > 0)
            {
                return false;
            }
            else
                return true;
        }

        /// <summary>
        /// Whether to stop the test suite.
        /// </summary>
        /// <returns></returns>
        public override bool ShouldStopTestSuite()
        {
            InitializeDynamicTraversalTimeOut();
            DateTime currentTime = DateTime.Now;
            TimeSpan collapsedTime = currentTime - startTime;
            if (collapsedTime > timeout)
                return true;
            else
                return false;
        }

        private void InitializeDynamicTraversalTimeOut()
        {
            if (!timeout.HasValue)
            {
                string value;
                if (testProperties.TryGetValue("dynamictraversaltimeout", out value))
                {
                    try
                    {
                        timeout = TimeSpan.FromMinutes(double.Parse(value));
                    }
                    catch (System.OverflowException)
                    {
                        throw new InvalidOperationException("DynamicTraversalTimeout property has invalid value");
                    }
                    catch (System.ArgumentException)
                    {
                        throw new InvalidOperationException("DynamicTraversalTimeout property has invalid value");
                    }
                }
                else
                {
                    throw new InvalidOperationException("Cannot get time out from test properties, please check your runtime configuration");
                }
            }
        }
    }
}
