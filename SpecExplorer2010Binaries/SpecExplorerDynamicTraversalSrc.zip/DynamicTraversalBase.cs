﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SpecExplorer.ObjectModel;
using Microsoft.SpecExplorer.Runtime;
using Microsoft.SpecExplorer.Runtime.Testing;

namespace Microsoft.SpecExplorer.DynamicTraversal
{
    /// <summary>
    /// An abstract dynamic traversal base class which can be inherited by a customized dynamic traversal.
    /// </summary>
    public abstract class DynamicTraversalBase : IDynamicTraversal
    {
        /// <summary>
        /// A mapping relation between call transition and its callback delegates.
        /// </summary>
        protected IDictionary<Transition, CallTransitionDelegate> callDelegates;

        /// <summary>
        /// A mapping relation between return transition and its callback delegates.
        /// </summary>
        protected IDictionary<Transition, ReturnTransitionDelegate> returnDelegates;

        /// <summary>
        /// A mapping relation between event transition and its callback delegates.
        /// </summary>
        protected IDictionary<Transition, EventTransitionDelegate> eventDelegates;

        /// <summary>
        /// Test properties associates with the traversal.
        /// </summary>
        protected IDictionary<string, string> testProperties;

        /// <summary>
        /// Transition system which is traversed on.
        /// </summary>
        protected TransitionSystem transitionSystem;

        /// <summary>
        /// Test initialize callback delegate.
        /// </summary>
        protected TestHousekeepingHandler testInitialize;
        
        /// <summary>
        /// Test cleanup callback delegate.
        /// </summary>
        protected TestHousekeepingHandler testCleanup;

        /// <summary>
        /// Delegate used to handle state reached event.
        /// </summary>
        /// <param name="state"></param>
        public delegate void StateNotificationHandler(State state);

        /// <summary>
        /// Delegate used to handle step taken event.
        /// </summary>
        /// <param name="step"></param>
        public delegate void StepNotificationHandler(Transition step);

        /// <summary>
        /// State notification handler which can be used to collect state coverage information.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        protected event StateNotificationHandler StateReached;

        /// <summary>
        /// Transition notification handler which can be used to collect transition coverage information.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        protected event StepNotificationHandler TransitionTaken;

        /// <summary>
        /// The start time of dynamic traversal.
        /// </summary>
        protected DateTime startTime;

        // Total number of test cases.
        private int testCaseCounter = 0;

        private bool shouldStopTestSuite = false;

        private int successTestCaseCount = 0;
        private int failedTestCaseCount = 0;
        private int stoppedTestCaseCount = 0;

        private const int PadLength = 30;

        private DynamicTraversalStatisticReporter reporter;

        #region IDynamicTraversal Properties

        /// <summary>
        /// The test manager used to monitor return/event queue, handle event/return selection.
        /// </summary>
        public ITestManager Manager { get; set; }

        /// <summary>
        /// Gets or sets quiescence timeout. 
        /// </summary>
        public TimeSpan QuiescenceTimeout { get; set; }

        /// <summary>
        /// Gets or sets proceed control timeout. 
        /// </summary>
        public TimeSpan ProceedControlTimeout { get; set; }

        #endregion

        #region IDynamicTraversal interface and RunTest function.

        /// <summary>
        /// In general, the strategy interacts with serialized transition system to verify SUT on the fly.
        /// </summary>
        /// <param name="transitionSystem">transition system used by traversal algorithm</param>
        /// <param name="callDelegates">a delegate dictionary which stores the delegates associate with each call transition</param>
        /// <param name="returnDelegates">a delegate dictionary which stores the delegates associate with each return transition </param>
        /// <param name="eventDelegates">a delegate dictionary which stores the delegates associate with each event transition</param>
        /// <param name="testInitialize">test manager attached to test strategy</param>
        /// <param name="testCleanup">test initialize delegate used before one new test case is started</param>
        /// <param name="testProperties">test properties for dynamic traversal which should be configured at test runtime</param>
        public void RunTestSuite(TransitionSystem transitionSystem, 
            IDictionary<Transition, CallTransitionDelegate> callDelegates, 
            IDictionary<Transition, ReturnTransitionDelegate> returnDelegates, 
            IDictionary<Transition, EventTransitionDelegate> eventDelegates, 
            TestHousekeepingHandler testInitialize, 
            TestHousekeepingHandler testCleanup,
            IDictionary<string, string> testProperties)
        {
            if (transitionSystem == null)
                throw new ArgumentNullException("transitionSystem");

            if (callDelegates == null)
                throw new ArgumentNullException("callDelegates");

            if (returnDelegates == null)
                throw new ArgumentNullException("returnDelegates");

            if (eventDelegates == null)
                throw new ArgumentNullException("eventDelegates");

            if(testInitialize == null)
                throw new ArgumentNullException("testInitialize");

            if(testCleanup == null)
                throw new ArgumentNullException("testCleanup");

            this.callDelegates = callDelegates;
            this.returnDelegates = returnDelegates;
            this.eventDelegates = eventDelegates;
            this.transitionSystem = transitionSystem;
            this.testInitialize = testInitialize;
            this.testCleanup = testCleanup;
            this.testProperties = testProperties;

            if (transitionSystem.InitialStates.Length <=0 ) 
            {   
                throw new InvalidOperationException("transition system doesn't contain any initial state");
            }

            reporter = new DynamicTraversalStatisticReporter(transitionSystem.Name);

            startTime = DateTime.Now;
            bool firsTime = true;
            do
            {
                if(testInitialize != null)
                    testInitialize();
                // Test Manager will be initialized for each test case.
                // reset its property here.
                this.Manager.ThrowTestFailureException = true;
                if (firsTime)
                {
                    firsTime = false;
                    reporter.ReportStatisticInformation("Begin Dynamic Traversal.");
                }
                // Add a new line between each test case.
                reporter.ReportStatisticInformation("");
                string testCaseName = GetUniqueTestCaseName();
                this.Manager.BeginTest(testCaseName);
                State state = ChooseInitialState();
                shouldStopTestSuite = ShouldStopTestSuite();
                if (!shouldStopTestSuite)
                    shouldStopTestSuite = RunTest(state, testCaseName) == TestSuiteStatus.Stopped ? true : false;
                this.Manager.EndTest();
                if(testCleanup != null)
                    testCleanup();

            } while (!shouldStopTestSuite);


            if (shouldStopTestSuite)
            {
                reporter.ReportStatisticInformation("Finished Dynamic Traversal (meets stop criteria).");
            }
            else
                reporter.ReportStatisticInformation("Finished Dynamic Traversal.");

            int totalTestCaseCount = successTestCaseCount + failedTestCaseCount + stoppedTestCaseCount;
            reporter.ReportStatisticInformation("");
            reporter.ReportStatisticInformation("Success Test Cases".PadRight(PadLength) + "Failed Test Cases".PadRight(PadLength)
                + "Stopped Test Cases".PadRight(PadLength) + "Total Test Cases".PadRight(PadLength));
            reporter.ReportStatisticInformation(successTestCaseCount.ToString().PadRight(PadLength) + failedTestCaseCount.ToString().PadRight(PadLength)
                + stoppedTestCaseCount.ToString().PadRight(PadLength) + totalTestCaseCount.ToString().PadRight(PadLength));
        }

        /// <summary>
        /// Run test from a given initial state.
        /// </summary>
        /// <param name="initialState"></param>
        /// <param name="testCaseName"></param>
        /// <returns>test suite executing status: stopped, running</returns>
        protected TestSuiteStatus RunTest(State initialState, string testCaseName)
        {
            State state = initialState;

            while (true)
            {
                if (ShouldStopTestSuite())
                {
                    ReportStoppedTestCase(testCaseName);
                    return TestSuiteStatus.Stopped;
                }
                if(StateReached != null)
                    StateReached(state);

                if (transitionSystem.IsAcceptingState(state) && ShouldStopTestCaseAt(state))
                    break;

                List<Transition> transitions;
                if (transitionSystem.TryGetOutgoingTransitions(state, out transitions))
                {
                    if (transitionSystem.ContainsReturnTransition(state)
                        && (transitionSystem.ContainsCallTransition(state) || transitionSystem.ContainsEventTransition(state)))
                    {
                        throw new InvalidOperationException(string.Format("Dynamic Traversal currently doesn't support a state ({0}) has return successor transition together with call/event transition.", state.Label));
                    }
                    else if (transitionSystem.ContainsReturnTransition(state))
                    {
                        try
                        {
                            int index = this.Manager.ExpectReturn(this.QuiescenceTimeout, true, GenerateExpectedReturns(transitions));
                            // if no return action is received
                            if (index == -1)
                            {
                                ReportFailedTestCase(testCaseName, string.Format("Test case {0} failed because no return action is received within timeout at state {1}", testCaseName, state.Label));
                                return TestSuiteStatus.Running;
                            }
                            else
                            {
                                // choose the received return transition
                                Transition transition = transitions[index];
                                state = transitionSystem.GetStateFromLabel(transition.Target);
                                if(TransitionTaken != null)
                                    TransitionTaken(transition);
                            }
                        }
                        catch (TestFailureException e)
                        {
                            ReportFailedTestCase(testCaseName, e);
                            return TestSuiteStatus.Running;
                        }
                    }
                    else if (transitionSystem.ContainsEventTransition(state))
                    {
                        try
                        {
                            IList<Transition> eventTransitions;
                            IList<Transition> controlTransitions;

                            SplitEventControlTransitions(transitions, out eventTransitions, out controlTransitions);
                            bool failIfNone = true;
                            if (controlTransitions.Count > 0)
                            {   
                                // if there is control transition besides event transition, 
                                // we can choose control transition  if no event transition is matched.
                                failIfNone = false;
                            }
                            int index = this.Manager.ExpectEvent(this.QuiescenceTimeout, failIfNone, GenerateExpectedEvents(eventTransitions));
                            // no event is received, choose one control transition
                            if (index == -1 && controlTransitions.Count > 0)
                            {
                                Transition selectedTransition = ChooseControllableTransition(state, controlTransitions);
                                // Invoke SUT method.
                                CallTransitionDelegate callTransitionDelegate;
                                if(!callDelegates.TryGetValue(selectedTransition, out callTransitionDelegate))
                                {
                                    throw new InvalidOperationException(
                                        string.Format("Cannot find call delegate for transition \"{0}\" from State {1} to State {2}", 
                                        selectedTransition.Action.Text, 
                                        selectedTransition.Source, 
                                        selectedTransition.Target));
                                }

                                if (InvokeCallTransition(testCaseName, ref state, selectedTransition, callTransitionDelegate))
                                    return TestSuiteStatus.Running;
                            }
                            else if(index == -1)
                            {
                                // no matched event(no event received within time out or doesn't match any expected event)
                                ReportFailedTestCase(testCaseName, string.Format("Test case {0} failed because no event received within time out or unexpected event received at state {1}", testCaseName, state.Label));
                                return TestSuiteStatus.Running;
                            }
                            else
                            {
                                // choose the received event transition
                                Transition transition = eventTransitions[index];
                                state = transitionSystem.GetStateFromLabel(transition.Target);
                                if(TransitionTaken != null)
                                    TransitionTaken(transition);
                            }
                        }
                        catch (TestFailureException e)
                        {
                            ReportFailedTestCase(testCaseName, e);
                            return TestSuiteStatus.Running;
                        }
                    }
                    else
                    {
                        // choose one control transition 
                        Transition selectedTransition = ChooseControllableTransition(state, transitions);
                        // Invoke control delegate.
                        if (InvokeCallTransition(testCaseName, ref state, selectedTransition, callDelegates[selectedTransition]))
                            return TestSuiteStatus.Running;
                    }
                }
                else
                {
                    // reach end state.
                    break;
                }
            }
            ReportSuccessTestCase(testCaseName);
            return TestSuiteStatus.Running;
        }

        // return value represents whether finish current test case
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        private bool InvokeCallTransition(string testCaseName, ref State state, Transition selectedTransition, CallTransitionDelegate callTransitionDelegate)
        {
            try
            {
                callTransitionDelegate.Invoke();
            }
            catch (Exception e)
            {
                if (TransitionTaken != null)
                    TransitionTaken(selectedTransition);
                ReportFailedTestCase(testCaseName, e);
                return true;
            }

            state = transitionSystem.GetStateFromLabel(selectedTransition.Target);

            if (TransitionTaken != null)
                TransitionTaken(selectedTransition);

            // if it's an unique return action for a call action, the delegate for call/return is wrapped together.
            // Raise state/transition visit events and find  target state of return transition as next traversed state.
            Transition returnTransition;
            if (transitionSystem.TryGetUniqueReturnTransition(selectedTransition, out returnTransition))
            {
                if (StateReached != null)
                    StateReached(state);

                if (TransitionTaken != null)
                    TransitionTaken(returnTransition);

                state = transitionSystem.GetStateFromLabel(returnTransition.Target);
            }
            return false; 
        }

        #endregion        

        #region Overide callback methods

        /// <summary>
        /// Choose an initial state from transition system
        /// </summary>
        /// <returns></returns>
        public abstract State ChooseInitialState();

        /// <summary>
        /// Choose a controllable transition.
        /// </summary>
        /// <returns></returns>
        public abstract Transition ChooseControllableTransition(State state, IList<Transition> transition);

        /// <summary>
        /// Whether to stop test case at an accepting state.
        /// </summary>
        /// <param name="acceptingState"></param>
        /// <returns></returns>
        public abstract bool ShouldStopTestCaseAt(State acceptingState);

        /// <summary>
        /// Whether to stop the test suite.
        /// </summary>
        /// <returns></returns>
        public abstract bool ShouldStopTestSuite();

        #endregion 

        #region Helper method

        /// <summary>
        /// Get an unique test case name.
        /// </summary>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate")]
        protected string GetUniqueTestCaseName()
        {
            string testCaseName = transitionSystem.Name + "Test" + testCaseCounter.ToString();
            testCaseCounter++;
            return testCaseName;
        }

        /// <summary>
        /// Generate ExpectedReturn array for a list of return transitions.
        /// </summary>
        /// <param name="returnTransitions"></param>
        /// <returns></returns>
        protected ExpectedReturn[] GenerateExpectedReturns(IList<Transition> returnTransitions)
        {
            List<ExpectedReturn> expectedReturns = new List<ExpectedReturn>();
            foreach (Transition transition in returnTransitions)
            {
                expectedReturns.Add(returnDelegates[transition].Invoke());
            }
            return expectedReturns.ToArray();
        }

        /// <summary>
        /// Generate ExpectedEvent array for a list of event transitions.
        /// </summary>
        /// <param name="eventTransitions"></param>
        /// <returns></returns>
        protected ExpectedEvent[] GenerateExpectedEvents(IList<Transition> eventTransitions)
        {
            List<ExpectedEvent> expectedEvents = new List<ExpectedEvent>();
            foreach (Transition transition in eventTransitions)
            {
                expectedEvents.Add(eventDelegates[transition].Invoke());
            }
            return expectedEvents.ToArray();
        }

        /// <summary>
        /// Split transtions to event transitions and control transitions.
        /// </summary>
        /// <param name="transitions"></param>
        /// <param name="eventTransitions"></param>
        /// <param name="controllableTransitions"></param>
        /// <returns></returns>
        protected void SplitEventControlTransitions(IList<Transition> transitions, out IList<Transition> eventTransitions, out IList<Transition> controllableTransitions)
        {
            eventTransitions = new List<Transition>();
            controllableTransitions = new List<Transition>();
            foreach (Transition transition in transitions)
            {
                if (transition.Action.Symbol.Kind == ActionSymbolKind.Event)
                    eventTransitions.Add(transition);
                else
                    controllableTransitions.Add(transition);
            }
            return;
        }

        private void ReportFailedTestCase(string testCaseName, Exception e)
        {
            string description = string.Format("Test case {0} failed with conformance error: \r\n    {1}.\r\n    StackTrace: {2}",
                testCaseName, e.Message, e.StackTrace);
            ReportFailedTestCase(testCaseName, description);
        }

        private void ReportFailedTestCase(string testCaseName, string description)
        {
            failedTestCaseCount++;
            Manager.Comment(description);
            reporter.ReportStatisticInformation(string.Format("Test case {0} failed. Log : {1} (or file which log is redirected to).", testCaseName, GetTestCaseLogFileName(testCaseName)));
        }

        private void ReportSuccessTestCase(string testCaseName)
        {
            successTestCaseCount++;
            reporter.ReportStatisticInformation(string.Format("Test case {0} passed. Log : {1} (or file which log is redirected to).", testCaseName, GetTestCaseLogFileName(testCaseName)));
        }

        private static string GetTestCaseLogFileName(string testCaseName)
        {
#if COMPACT
            string currentDirectory = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
#else
            string currentDirectory = Directory.GetCurrentDirectory();
#endif
            return Path.Combine(currentDirectory, testCaseName) + ".log";
        }

        private void ReportStoppedTestCase(string testCaseName)
        {
            stoppedTestCaseCount++;
            reporter.ReportStatisticInformation(string.Format("Test case {0} stopped. Log : {1} (or file which log is redirected to).", testCaseName, GetTestCaseLogFileName(testCaseName)));
        }

        #endregion
    }

    /// <summary>
    /// The status of executing test suite
    /// </summary>
    public enum TestSuiteStatus
    {
        /// <summary>
        /// Continue running test suite
        /// </summary>
        Running,

        /// <summary>
        /// Stop running test suite
        /// </summary>
        Stopped,
    }
}
