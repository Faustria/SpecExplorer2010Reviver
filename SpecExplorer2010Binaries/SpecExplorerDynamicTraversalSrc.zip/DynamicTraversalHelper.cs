﻿using System;
using System.Xml;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SpecExplorer.ObjectModel;
using System.Xml.Serialization;
using System.IO;

namespace Microsoft.SpecExplorer.DynamicTraversal
{
    /// <summary>
    /// A helper class.
    /// </summary>
    public static class DynamicTraversalHelper
    {
        /// <summary>
        /// Deserialize transition system object model from the string value.
        /// </summary>
        /// <param name="splitSerializedTransitionSystem"></param>
        /// <returns></returns>
        public static TransitionSystem GetTransitionSystem(string[] splitSerializedTransitionSystem)
        {
            XmlSerializer x = new XmlSerializer(typeof(TransitionSystem));
            string serializedTransitionSystem = "";
            foreach (string splitValue in splitSerializedTransitionSystem)
                serializedTransitionSystem += splitValue;
            byte[] byteArray = Encoding.Unicode.GetBytes(serializedTransitionSystem);
            TransitionSystem transitionSystem;
            using(MemoryStream stream = new MemoryStream(byteArray))
            {
                using (XmlTextReader reader = new XmlTextReader(stream))
                {
                    // turn off normalization, then xml de-serialization ignores invalid character checking.
                    reader.Normalization = false;
                    transitionSystem = (TransitionSystem)x.Deserialize(reader);
#if COMPACT
                    transitionSystem.LinkSystem(true);
#endif               
                }         
            }
            return transitionSystem;
        }
    }
}
