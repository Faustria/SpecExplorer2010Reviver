﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Microsoft.SpecExplorer.DynamicTraversal
{
    internal class DynamicTraversalStatisticReporter
    {
        private string filePath;
        private const int MaxLinesToConsole = 100;
        private int linesToConsole = 0;
        private bool hasAddedStatisticInformation;

        internal DynamicTraversalStatisticReporter(string machineName)
        {
#if COMPACT
            filePath = Path.Combine(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase), machineName) + ".log";
#else
            filePath = Path.Combine(Directory.GetCurrentDirectory(), machineName) + ".log";
#endif
        }

        internal void ReportStatisticInformation(string description)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Append))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    sw.WriteLine(description);
                    if (linesToConsole < MaxLinesToConsole)
                    {
                        linesToConsole++;
                        Console.WriteLine(description);
                    }
                    else if(!hasAddedStatisticInformation)
                    {
                        hasAddedStatisticInformation = true;
                        Console.WriteLine("");
                        Console.WriteLine(string.Format("Please see {0} (or file which log is redirected to) for more information...", filePath));
                    }
                }
            }
        }
    }
}
