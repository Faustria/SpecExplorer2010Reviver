using System;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Microsoft.SpecExplorer.Runtime.Testing
{
    /// <summary>
    /// An implementation of a Spec Explorer test class base which is 
    /// integrating into the VSTT unit testing framework.
    /// </summary>
    public class VsTestClassBase : GeneratedTestClassBase, IDisposable
    {
        private FileStream currentFileStream;
        private StreamWriter currentStreamWriter;

        /// <summary>
        /// See <see cref="Microsoft.SpecExplorer.Runtime.Testing.GeneratedTestClassBase.BeginTest"/>
        /// </summary>
        /// <param name="name"></param>
        public override void BeginTest(string name)
        {
            string description = "Begin executing test " + name;
            if (LogToFile)
            {
                string fullPath = Path.Combine(Directory.GetCurrentDirectory(), name) + ".log";
                currentFileStream = File.Open(fullPath, FileMode.OpenOrCreate);
                currentStreamWriter = new StreamWriter(currentFileStream);
                currentStreamWriter.WriteLine(description);
            }
            else
                Console.WriteLine(description);
        }

        /// <summary>
        /// See <see cref="Microsoft.SpecExplorer.Runtime.Testing.GeneratedTestClassBase.EndTest"/>
        /// </summary>
        public override void EndTest()
        {
            string description = "End executing test";
            if (LogToFile)
            {
                currentStreamWriter.WriteLine(description);
                if(currentStreamWriter != null)
                    currentStreamWriter.Close();
                if(currentFileStream != null)
                    currentFileStream.Close();
            }
            else
                Console.WriteLine(description);
        }

        /// <summary>
        /// See <see cref="Microsoft.SpecExplorer.Runtime.Testing.GeneratedTestClassBase.Assert"/>
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="description"></param>
        public override void Assert(bool condition, string description)
        {
            if (!condition)
                throw new AssertFailedException(description);
        }

        /// <summary>
        /// See <see cref="Microsoft.SpecExplorer.Runtime.Testing.GeneratedTestClassBase.Assume"/>
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="description"></param>
        public override void Assume(bool condition, string description)
        {
            if (!condition)
                throw new AssertInconclusiveException(description);
        }

        /// <summary>
        /// See <see cref="Microsoft.SpecExplorer.Runtime.Testing.GeneratedTestClassBase.Checkpoint"/>
        /// </summary>
        /// <param name="description"></param>
        public override void Checkpoint(string description)
        {
            string text = "Reaching checkpoint: " + description;
            if (LogToFile && currentStreamWriter != null)
            {
                currentStreamWriter.WriteLine(text);
            }
            else
                Console.WriteLine(text);
        }

        /// <summary>
        /// See <see cref="Microsoft.SpecExplorer.Runtime.Testing.GeneratedTestClassBase.Checkpoint"/>
        /// </summary>
        /// <param name="description"></param>
        public override void Comment(string description)
        {
            if (LogToFile && currentStreamWriter != null)
            {
                currentStreamWriter.WriteLine(description);
            }
            else
                Console.WriteLine(description);
        }

        #region IDisposable Members

        private bool disposed;

        /// <summary>
        /// Release resources.
        /// </summary>
        public void Dispose()
        {
            // Check to see if Dispose has already been called.
            if (!this.disposed)
            {
                // Dispose managed resources.
                if( currentStreamWriter != null)
                {
                    currentStreamWriter.Dispose();
                    currentStreamWriter = null;
                }
                if (currentFileStream != null)
                {
                    currentFileStream.Dispose();
                    currentFileStream = null;
                }
                
                // Note disposing has been done.
                disposed = true;
                GC.SuppressFinalize(this);
            }
        }

        #endregion

    }
}
